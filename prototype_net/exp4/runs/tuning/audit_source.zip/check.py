import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import joblib
import numpy as np

import prototype_net.exp4.baseline as b
from prototype_net.exp4.model import predict

run=Path('prototype_net/exp4/runs/embeddings')
with tempfile.TemporaryDirectory() as folder:
    out=Path(folder)/'trial'
    b.prepare_tuning(out,run)
    reg=json.loads((out/'registration.json').read_text())
    reg['stage1']=dict(max_depth=[1],n_estimators=[3],learning_rate=[.1],min_child_weight=[3])
    reg['stage2']=dict(reg_lambda=[10],reg_alpha=[0],subsample=[1.],colsample_bytree=[1.])
    (out/'registration.json').write_text(json.dumps(reg))
    native=np.load
    def train_only(path,*args,**kwargs):
        if Path(path).name=='holdout.npz':raise AssertionError('Holdout accessed while selecting')
        return native(path,*args,**kwargs)
    with patch.object(b.np,'load',side_effect=train_only):
        record=b.tuning_fold((out,0))
    bundle=joblib.load(out/'fold01.joblib')
    d=np.load(out/'train.npz')
    train=set(bundle['outer']['fit']); outer=set(bundle['outer']['score'])
    assert not train&outer
    covered=[]
    for inner in bundle['inner']:
        fit,score=set(inner['fit']),set(inner['score'])
        assert fit|score==train and not fit&score
        assert not (fit|score)&outer
        covered.extend(score)
    assert set(covered)==train and len(covered)==len(train)
    assert set(bundle['inner_batch_owner'])<=train
    assert np.isfinite(bundle['inner_oof']).all()
    old=joblib.load(run/'fold01.joblib')['models']['xgboost_0']
    np.testing.assert_array_equal(predict(old,d['x']),predict(bundle['models']['current'],d['x']))
    ones=b.distance_gate(dict(batch_owner=np.array(['p','q'])),dict(metric='none',threshold=0))
    np.testing.assert_array_equal(ones,[True,True])
    gate=b.distance_gate(dict(batch_owner=np.array(['p','q']),distance=np.array([.5,1.5])),dict(metric='distance',threshold=1))
    np.testing.assert_array_equal(gate,[False,True])
    p=np.array([.45,.65]);y=np.array([0,1])
    assert b.tuning_metrics(y,p,.6)['accuracy']==1
    assert b.tuning_metrics(y,p, .7)['accuracy']==.5
    assert b.tuning_metrics(y,p*np.array([False,False]),.6)['auroc']==.5
    fit=np.isin(d['owner'],list(train))
    for model in bundle['models'].values():
        np.testing.assert_allclose(model['preprocess']['scaler'].mean_,d['x'][fit].mean(0,dtype=float),atol=1e-12)
    try:
        b.evaluate_tuning(out)
        raise AssertionError('Evaluation did not require frozen selection')
    except FileNotFoundError:
        pass
    print('Passed: nested participant separation, blocked holdout reads, complete OOF predictions, control matches existing model, train-only preprocessing, threshold/gate mechanics, freeze required.')
