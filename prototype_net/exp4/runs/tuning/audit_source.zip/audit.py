import hashlib
import json
import zipfile
from pathlib import Path

import joblib
import numpy as np
import torch
from sklearn.metrics import accuracy_score, balanced_accuracy_score, confusion_matrix, roc_auc_score
from threadpoolctl import threadpool_limits

from prototype_net.exp4.model import fit_model, predict, sha256, write_json

torch.set_num_threads(1)
out=Path('prototype_net/exp4/runs/tuning')
reg=json.loads((out/'registration.json').read_text())
freeze=json.loads((out/'freeze.json').read_text())
results=json.loads((out/'results.json').read_text())
train=np.load(out/'train.npz'); held=np.load(out/'holdout.npz'); predictions=np.load(out/'predictions.npz')
assert freeze['registration_sha256']==sha256(out/'registration.json')
assert sha256(out/'train.npz')==reg['train_sha256']
assert sha256(out/'holdout.npz')==reg['holdout_sha256']
assert sha256(Path(reg['encoder']))==reg['encoder_sha256']
assert not set(train['owner'])&set(held['batch_owner'])
assert len(freeze['models'])==25
with zipfile.ZipFile(out/'source.zip') as z:
    for name,h in reg['source_hashes'].items():
        assert sha256(name)==h==hashlib.sha256(z.read(name)).hexdigest()

def grouped(owners,y,p):
    ids=np.unique(owners)
    return np.array([y[np.flatnonzero(owners==u)[0]] for u in ids]),np.array([p[owners==u].mean() for u in ids])

def measure(y,p,t):
    flag=p>=t;tn,fp,fn,tp=confusion_matrix(y,flag,labels=[0,1]).ravel()
    return dict(accuracy=float(accuracy_score(y,flag)),balanced_accuracy=float(balanced_accuracy_score(y,flag)),
        auroc=float(roc_auc_score(y,p)),sensitivity=float(tp/(tp+fn)),specificity=float(tn/(tn+fp)),
        confusion_matrix=[[int(tn),int(fp)],[int(fn),int(tp)]])

def close(actual,expected):
    for k in expected:
        np.testing.assert_allclose(actual[k],expected[k],rtol=0,atol=1e-12)

original=Path(reg['classifier_run']);original_reg=json.loads((original/'registration.json').read_text())
assert sha256(original/'registration.json')==reg['original_registration_sha256']
assert reg['folds']==original_reg['folds']
assert not set(original_reg['splits']['validation'])&set(original_reg['splits']['test'])
batch_features=np.concatenate([train['batch_x'],held['batch_x']])
outer_rows=[];inner_models=0
with threadpool_limits(limits=1):
    for record in freeze['models']:
        index=record['index'];path=out/f'fold{index:02d}.joblib'
        assert sha256(path)==record['sha256'];b=joblib.load(path)
        assert b['registration_sha256']==sha256(out/'registration.json')
        outer_fit,outer_score=set(b['outer']['fit']),set(b['outer']['score'])
        assert not outer_fit&outer_score and outer_fit|outer_score==set(train['owner'])
        fit=np.isin(train['owner'],list(outer_fit));within=np.isin(train['batch_owner'],list(outer_fit))
        bx,bo,by=train['batch_x'][within],train['batch_owner'][within],train['batch_y'][within]
        np.testing.assert_array_equal(bo,b['inner_batch_owner'])
        oof=np.full(len(bx),np.nan);seen=[];inner_metrics=[]
        for fold in b['inner']:
            f,s=set(fold['fit']),set(fold['score'])
            assert not f&s and f|s==outer_fit and not (f|s)&outer_score
            seen.extend(s)
            mask=np.isin(train['owner'],fold['fit']);score=np.isin(bo,fold['score'])
            m=fit_model('xgboost',train['x'][mask],train['y'][mask],train['owner'][mask],
                'classification','none',0,parameters=b['parameters'])
            oof[score]=predict(m,bx[score].reshape(-1,128)).reshape(-1,6).mean(1)
            iy,ip=grouped(bo[score],by[score],oof[score]);inner_metrics.append(measure(iy,ip,.5))
            inner_models+=1
        assert set(seen)==outer_fit and len(seen)==len(outer_fit)
        np.testing.assert_array_equal(oof,b['inner_oof'])
        for stage,count in [(1,36),(2,24)]:
            choices=[r for r in b['search'] if r['stage']==stage];assert len(choices)==count
            best=max(choices,key=lambda r:(r['auroc'],r['balanced_accuracy'],-r['candidate']))
            if stage==1:
                first=best['parameters']
            else:
                assert best['parameters']==b['parameters']
                for k,v in first.items():assert b['parameters'][k]==v
                for metric in ('auroc','balanced_accuracy'):
                    np.testing.assert_allclose(best[metric],np.mean([r[metric] for r in inner_metrics]),rtol=0,atol=1e-12)
        y,p=grouped(bo,by,oof)
        for row in b['threshold_scores']:
            close(row,measure(y,p,row['threshold']))
        selected=max(b['threshold_scores'],key=lambda r:(r['balanced_accuracy'],-abs(r['threshold']-.5),-r['threshold']))
        assert b['threshold']==selected['threshold']
        for g in b['gates']:
            policy=g['policy']
            gate=np.ones(len(bo),dtype=bool) if policy['metric']=='none' else train[policy['metric']][within]>=policy['threshold']
            if policy['metric']!='none':
                assert policy['threshold'] in np.quantile(train[policy['metric']][within],reg['distance_quantiles'])
            yy,pp=grouped(bo,by,oof*gate);close(g['metrics'],measure(yy,pp,b['threshold']))
        chosen=max(range(len(b['gates'])),key=lambda i:(b['gates'][i]['metrics']['balanced_accuracy'],b['gates'][i]['metrics']['sensitivity'],-i))
        assert b['policy']==b['gates'][chosen]['policy']
        old=joblib.load(original/f'fold{index:02d}.joblib')['models']['xgboost_0']
        np.testing.assert_array_equal(predict(old,batch_features.reshape(-1,128)),predict(b['models']['current'],batch_features.reshape(-1,128)))
        for m in b['models'].values():
            assert m['parents']==[] and m['fit_rows']==int(fit.sum()) and m['real_people']==len(outer_fit)
            np.testing.assert_allclose(m['preprocess']['scaler'].mean_,train['x'][fit].mean(0,dtype=float),rtol=0,atol=1e-12)
        score=np.isin(train['batch_owner'],list(outer_score))
        for arm in reg['arms']:
            m=b['models']['current' if arm=='current' else 'tuned'];t=.5 if arm=='current' else b['threshold']
            cvp=predict(m,train['batch_x'][score].reshape(-1,128)).reshape(-1,6).mean(1).astype(float)
            hp=predict(m,held['batch_x'].reshape(-1,128)).reshape(-1,6).mean(1).astype(float)
            if arm=='tuned_distance' and b['policy']['metric']!='none':
                key=b['policy']['metric'];limit=b['policy']['threshold']
                cvp*=train[key][score]>=limit;hp*=held[key]>=limit
            np.testing.assert_array_equal(cvp,b['outer_predictions'][arm])
            y,p=grouped(train['batch_owner'][score],train['batch_y'][score],cvp)
            actual=measure(y,p,t);close(b['cv'][arm],actual);outer_rows.append(dict(arm=arm,**actual))
            np.testing.assert_array_equal(hp,predictions[arm][index-1])
            for role in ('validation','test'):
                ix=held['split']==role;y,p=grouped(held['batch_owner'][ix],held['batch_y'][ix],hp[ix])
                row=next(r for r in results['rows'] if r['index']==index and r['arm']==arm and r['role']==role)
                close(row,measure(y,p,t));close(row['batch_metrics'],measure(held['batch_y'][ix],hp[ix],t))
        print('Audited fold',index,flush=True)

for a in results['aggregates']:
    rows=[r for r in outer_rows if r['arm']==a['arm']] if a['role']=='cv' else [r for r in results['rows'] if r['arm']==a['arm'] and r['role']==a['role']]
    for m in ('accuracy','balanced_accuracy','auroc','sensitivity','specificity'):
        close(a[m],dict(mean=float(np.mean([r[m] for r in rows])),sd=float(np.std([r[m] for r in rows],ddof=1))))
    if a['role']!='cv':
        mask=held['split']==a['role'];p=predictions[a['arm']].mean(0)[mask]
        y,v=grouped(held['batch_owner'][mask],held['batch_y'][mask],p)
        t=.5 if a['arm']=='current' else predictions['thresholds'].mean()
        close(a['ensemble'],measure(y,v,t));close(a['batch_ensemble'],measure(held['batch_y'][mask],p,t))
exports=Path('prototype_net/exp4/runs/exports')
verification=json.loads((exports/'verification.json').read_text())
for name,h in verification['artifacts'].items():assert sha256(exports/name)==h
write_json(out/'verification.json',dict(passed=True,outer_folds=25,selected_inner_models_refitted=inner_models,
    nested_participant_splits_verified=True,selection_recomputed=True,train_only_preprocessing_verified=True,
    all_predictions_and_metrics_reproduced=True,current_controls_match_original_models=True,
    original_exports_unchanged=True,registration_sha256=sha256(out/'registration.json'),
    freeze_sha256=sha256(out/'freeze.json'),predictions_sha256=sha256(out/'predictions.npz')))
with zipfile.ZipFile(out/'audit_source.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    z.write('/tmp/exp4_tuning_check.py','check.py');z.write(__file__,'audit.py')
print('All nested selection, checkpoints, predictions, gates and metrics passed.')
