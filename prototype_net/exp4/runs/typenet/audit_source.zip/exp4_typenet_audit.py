from pathlib import Path
import json
import hashlib
import numpy as np
from prototype_net.exp4.model import ROOT, MODELS, sha256, typenet_fidelity, write_json
out = ROOT/'prototype_net/exp4/runs/typenet'
reg = json.loads((out/'registration.json').read_text())
with np.load(out/'dataset.npz', allow_pickle=False) as z:
    data = {k:z[k] for k in z.files}
assert [len(reg['splits'][r]) for r in ('train','validation','test')] == [59,9,17]
assert len(data['x']) == 14235 and data['x'].shape[1] == 135
assert np.isfinite(data['x']).all()
assert set(np.unique(data['owner'])) == set(sum(reg['splits'].values(), []))
for owner in np.unique(data['owner']):
    mask = data['owner'] == owner
    assert len(np.unique(data['split'][mask])) == 1
    assert len(np.unique(data['y'][mask])) == 1
    assert sum(data['synthetic'][mask]) == 128
for i in np.flatnonzero(data['synthetic']):
    ids = data['lineage'][i]
    ancestor = data['events'][ids]
    assert (ancestor[:,0] == data['owner'][i]).all()
    for block in (ancestor[:25], ancestor[25:]):
        assert len(np.unique(block[:,1])) == 1
        assert (np.diff(block[:,2].astype(int)) == 1).all()
    hl = ancestor[:50,4].astype(float)
    assert np.allclose(data['sequences'][i,:,0], hl)
    assert np.allclose(data['sequences'][i,:,4],ancestor[:50,5].astype(float)/255)
assert all(set(f['fit'])|set(f['score']) == set(reg['splits']['train']) and not set(f['fit'])&set(f['score']) for f in reg['folds'])
for repeat in range(1,6):
    assert sorted(sum([f['score'] for f in reg['folds'] if f['repeat']==repeat],[])) == sorted(reg['splits']['train'])
fold_fidelity = []
for i, fold in enumerate(reg['folds']):
    check = typenet_fidelity(data, np.isin(data['owner'], fold['fit']))
    fold_fidelity.append(dict(index=i+1, **check))
real_sequences = {hashlib.sha256(row.tobytes()).digest() for row in data['sequences'][~data['synthetic']]}
synthetic_copy_count = sum(hashlib.sha256(row.tobytes()).digest() in real_sequences for row in data['sequences'][data['synthetic']])
result = dict(passed=True, lineage_checked=int(data['synthetic'].sum()), real_synthetic_exact_copies=synthetic_copy_count,
              dataset_sha256=sha256(out/'dataset.npz'), registration_sha256=sha256(out/'registration.json'),
              fold_fidelity=fold_fidelity)
write_json(out/'audit.json',result)
print(json.dumps({k:v for k,v in result.items() if k != 'fold_fidelity'}), flush=True)
