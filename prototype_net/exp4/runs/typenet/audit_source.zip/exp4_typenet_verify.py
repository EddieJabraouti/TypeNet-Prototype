import json
import numpy as np
import joblib
from prototype_net.exp4.model import ROOT, MODELS, sha256, write_json, typenet_verify
out=ROOT/'prototype_net/exp4/runs/typenet'
reg=typenet_verify(out)
freeze=json.loads((out/'freeze.json').read_text())
assert freeze['registration_sha256']==sha256(out/'registration.json')
assert len(freeze['models'])==25
with np.load(out/'dataset.npz',allow_pickle=False) as z:
    data={k:z[k] for k in ('x','y','owner','synthetic','split')}
fit_counts=[]
for record in freeze['models']:
    p=out/f"fold{record['index']:02d}.joblib"
    assert sha256(p)==record['sha256']
    bundle=joblib.load(p)
    assert len(bundle['models'])==8
    assert bundle['selected']==record['selected']
    assert bundle['overall']==record['overall']
    fit=np.isin(data['owner'],bundle['fold']['fit'])
    assert (data['split'][fit]=='train').all()
    for family in MODELS:
        candidates=[r for r in bundle['results'] if r['family']==family]
        best=max(candidates,key=lambda r:(r['scores']['combined']['accuracy'],r['scores']['combined']['auroc'],-r['synthetic_per_person']))
        assert bundle['selected'][family]==best['candidate']
        for result in candidates:
            model=bundle['models'][result['candidate']]
            mask=fit & (~data['synthetic'] | (result['synthetic_per_person']>0))
            assert model['fit_rows']==int(mask.sum())
            assert model['encoder'] is None
            assert np.allclose(model['preprocess']['scaler'].mean_, data['x'][mask].mean(axis=0,dtype=float),rtol=1e-12,atol=1e-12)
            if family in ('tabnet','node'):
                assert model['epochs']==100 and model['features']==135
            fit_counts.append(model['fit_rows'])
results=json.loads((out/'results.json').read_text())
assert len(results['cv'])==200 and len(results['rows'])==250
with np.load(out/'predictions.npz',allow_pickle=False) as predictions:
    for row in results['rows']:
        mask=data['split']==row['role']
        score=predictions[f"fold{row['index']:02d}_{row['role']}_{row['candidate']}"]
        assert np.isfinite(score).all() and len(score)==mask.sum()
        assert row['combined']['accuracy']==float(np.mean((score>=.5)==data['y'][mask]))
        assert sum(map(sum,row['combined']['confusion_matrix']))==mask.sum()
    for aggregate in results['aggregates']:
        rows=[r for r in results['rows'] if r['family']==aggregate['family'] and r['role']==aggregate['role']]
        assert len(rows)==25
        for unit in ('combined','real_participants'):
            for metric, values in aggregate[unit].items():
                scores=[r[unit][metric] for r in rows]
                assert values['mean']==float(np.mean(scores))
                assert values['sd']==float(np.std(scores,ddof=1))
assert sha256(ROOT/'prototype_net/exp4/runs/motor_pd/tabnet_smote_pretrained.joblib')=='03b9f891e9f73e5613a789966e3804c1a5d06a570141df34a6656b4775fe59fe'
write_json(out/'verification.json',dict(passed=True,models_checked=200,selected_evaluations_checked=250,
    checks=['all checkpoint and source hashes','unchanged frozen TypeNet and original TabNet checkpoint','participant-disjoint folds','fold-only scaler fit statistics','CV-only selections','100 neural epochs','saved predictions reproduce accuracy','mean and sample SD recomputed'],
    results_sha256=sha256(out/'results.json'),fit_rows_range=[min(fit_counts),max(fit_counts)]))
print('PASS: 200 models, 250 evaluations, train-only preprocessing, CV selection, prediction metrics, sample SD and unchanged checkpoints.')
