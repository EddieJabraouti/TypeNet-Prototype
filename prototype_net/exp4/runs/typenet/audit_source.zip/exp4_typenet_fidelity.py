import json
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score, balanced_accuracy_score
from xgboost import XGBClassifier
from threadpoolctl import threadpool_limits
from prototype_net.exp4.model import ROOT, SEED, write_json
out=ROOT/'prototype_net/exp4/runs/typenet'
reg=json.loads((out/'registration.json').read_text())
with np.load(out/'dataset.npz',allow_pickle=False) as z:
    mask=(z['split']=='train') & (z['lengths']==50)
    data={k:z[k][mask] for k in ('x','owner','synthetic')}
results=[]
with threadpool_limits(limits=1):
    for fold in reg['folds'][:5]:
        fit=np.isin(data['owner'],fold['fit']); score=np.isin(data['owner'],fold['score'])
        y=data['synthetic'][fit].astype(int); ids=data['owner'][fit]
        weights=np.array([1/sum((ids==owner)&(y==origin)) for owner,origin in zip(ids,y)])
        weights*=len(weights)/weights.sum()
        model=XGBClassifier(n_estimators=50,max_depth=3,learning_rate=.05,n_jobs=1,random_state=SEED,tree_method='hist')
        model.fit(data['x'][fit],y,sample_weight=weights)
        p=model.predict_proba(data['x'][score])[:,1]
        sy=data['synthetic'][score].astype(int); si=data['owner'][score]
        sw=np.array([1/sum((si==owner)&(sy==origin)) for owner,origin in zip(si,sy)])
        results.append(dict(fold=fold['fold'],auroc=float(roc_auc_score(sy,p,sample_weight=sw)),balanced_accuracy=float(balanced_accuracy_score(sy,p>=.5,sample_weight=sw))))
result=dict(method='Train-only, source-disjoint five-fold classifier discriminating real versus synthetic 50-stroke embeddings and summaries; equal source and origin weights; .5 AUROC is indistinguishable to this classifier.',folds=results,mean_auroc=float(np.mean([r['auroc'] for r in results])),sd_auroc=float(np.std([r['auroc'] for r in results],ddof=1)))
write_json(out/'fidelity.json',result)
print(json.dumps(result))
