import copy
import json
import tempfile
from pathlib import Path

import numpy as np
import torch

from prototype_net.exp4.model import BaselineMonitor, PersonalMonitor, baseline_distance

torch.set_num_threads(1)
rng = np.random.default_rng(9172026)
b = rng.normal(size=(18, 128))
x = rng.normal(size=(6, 128))
assert baseline_distance(b, b)['mmd2'] < 1e-12
assert baseline_distance(b, b+20)['mmd2'] > baseline_distance(b, x)['mmd2']
for key in ('mmd2', 'embedding_distance', 'baseline_within_distance', 'embedding_distance_ratio'):
    np.testing.assert_allclose(baseline_distance(b, x)[key], baseline_distance(b[::-1], x[::-1])[key], atol=1e-12)
assert baseline_distance(np.zeros((6,128)), x)['embedding_distance_ratio'] is None

class Engine:
    batch_size = 6
    features = 128
    models = [None]*25
    fingerprint = 'test-model'
    family = 'xgboost'
    def __init__(self):
        self.values = rng.normal(size=(6,128)).astype(np.float32)
        self.score = .7
    def encode(self, events):
        return self.values, [str(e) for e in events], 6
    def probabilities(self, features):
        return np.full((25,6), self.score)

def payload(n):
    return dict(participant_id='p', context_id='keyboard', batch_id=str(n),
                sequence_number=n, events=list(range(300*n,300*(n+1))))

engine = Engine()
m = BaselineMonitor(engine, 'p', 'keyboard', 3)
for i in range(3):
    result = m.observe(payload(i))
    assert result['status'] == ('baseline_ready' if i == 2 else 'enrolling')
    assert 'flag' not in result
baseline, baseline_scores = m.baseline.copy(), m.baseline_scores.copy()
assert m.observe(payload(3))['flag'] == 1
assert m.observe(payload(4))['positive_streak'] == 2
engine.score = .4
engine.values += 100
result = m.observe(payload(5))
assert result['mmd2'] > .5 and result['flag'] == 0 and result['positive_streak'] == 0
assert result['pd_score_change'] < 0
np.testing.assert_array_equal(m.baseline, baseline)
np.testing.assert_array_equal(m.baseline_scores, baseline_scores)
for field, value in [('participant_id','q'),('context_id','other'),('batch_id','0'),
                     ('sequence_number',4),('events',payload(0)['events']),('events',[1])]:
    bad = payload(6); bad[field] = value
    before = json.dumps(m.state, sort_keys=True)
    try:
        m.observe(bad)
        raise AssertionError('Invalid input accepted: '+field)
    except ValueError:
        pass
    assert json.dumps(m.state, sort_keys=True) == before
with tempfile.TemporaryDirectory() as folder:
    path = Path(folder)/'state.npz'
    m.save(path)
    other = BaselineMonitor(engine, 'p', 'keyboard', 3)
    other.restore(path)
    assert m.observe(payload(6)) == other.observe(payload(6))
    for args in [('q','keyboard',3),('p','other',3),('p','keyboard',1)]:
        try:
            BaselineMonitor(engine,*args).restore(path)
            raise AssertionError('Mismatched state accepted')
        except ValueError:
            pass

real = PersonalMonitor(Path('prototype_net/exp4/runs/embeddings'), 'test', batch_size=6)
source = Path('prototype_net/exp4/runs/baseline_embeddings')
d = np.load(source/'300/dataset.npz')
events = np.load(source/'events.npz')['events']
uid = str(d['owner'][0])
ids = np.flatnonzero((d['owner']==uid) & (d['batch']==0))
rows = events[d['lineage'][ids].reshape(-1)]
p = dict(participant_id=uid, context_id='keyboard', batch_id='0', sequence_number=0,
         events=[dict(session_id=str(e[1]),event_id=str(e[2]),keydown_ms=float(e[3]),
                      keyup_ms=float(e[4]),keycode=float(e[5])) for e in rows])
monitor = BaselineMonitor(real,uid,'keyboard')
before = {k:v.clone() for k,v in real.encoder.state_dict().items()}
assert monitor.observe(p)['status'] == 'baseline_ready'
np.testing.assert_allclose(monitor.baseline[0],d['x'][ids],atol=2e-5,rtol=2e-5)
assert all(torch.equal(v,before[k]) for k,v in real.encoder.state_dict().items())
for mutation in ('duplicate','timestamp','keycode'):
    bad = copy.deepcopy(p); bad['batch_id']='1'; bad['sequence_number']=1
    if mutation == 'duplicate': bad['events'][1] = bad['events'][0]
    if mutation == 'timestamp': bad['events'][0]['keyup_ms'] = -1
    if mutation == 'keycode': bad['events'][0]['keycode'] = float('nan')
    try:
        monitor.observe(bad)
        raise AssertionError('Invalid real events accepted')
    except ValueError:
        pass
print('Passed: fixed baseline, ordering/context/event guards, restore, raw-input fidelity, frozen encoder, MMD invariance, classification independent of anomaly magnitude.')
