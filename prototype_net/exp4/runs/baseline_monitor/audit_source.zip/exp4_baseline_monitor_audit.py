import hashlib
import json
import zipfile
from pathlib import Path

import joblib
import numpy as np
from sklearn.metrics import accuracy_score, roc_auc_score

from prototype_net.exp4.model import predict, sha256, write_json

p = Path('prototype_net/exp4/runs/baseline_monitor')
r = json.loads((p/'registration.json').read_text())
source = Path('prototype_net/exp4/runs/baseline_embeddings')
model_run = Path(r['classifier_run'])
assert sha256(model_run/'freeze.json') == r['classifier_freeze_sha256']
assert sha256(source/'300/dataset.npz') == r['dataset_sha256']
assert sha256(source/'events.npz') == r['events_sha256']
with zipfile.ZipFile(p/'source.zip') as z:
    for name,h in r['source_hashes'].items():
        assert sha256(name) == h == hashlib.sha256(z.read(name)).hexdigest()
d = np.load(source/'300/dataset.npz')
s = np.load(p/'scores.npz')
rows = json.loads((p/'history.json').read_text())
result = json.loads((p/'results.json').read_text())
freeze = json.loads((model_run/'freeze.json').read_text())
max_error = 0.
for record in freeze['models']:
    path = model_run/f"fold{record['index']:02d}.joblib"
    assert sha256(path) == record['sha256']
    model = joblib.load(path)['models']['xgboost_0']
    assert model['preprocess']['scaler'].n_features_in_ == 128
    prediction = predict(model, d['x'])
    replay = np.array([prediction[(d['owner']==uid)&(d['batch']==b)].mean()
                       for uid,b in zip(s['owner'],s['batch'])])
    error = float(np.max(abs(replay-s['scores'][:,record['index']-1])))
    max_error = max(max_error,error)
    np.testing.assert_allclose(replay,s['scores'][:,record['index']-1],atol=1e-7,rtol=0)

lookup = {(str(u),int(b)):i for i,(u,b) in enumerate(zip(s['owner'],s['batch']))}
streaks = {}
for row in rows:
    uid, batch, n = row['participant_id'],row['sequence_number'],row['baseline_setting']
    ix = lookup[uid,batch]
    score = s['scores'][ix].mean()
    np.testing.assert_equal(score,row['pd_score'])
    if row['status'] != 'scored':
        assert batch<n and 'flag' not in row
        continue
    assert batch>=n
    assert row['flag'] == int(score>=.5)
    key = (uid,n)
    streaks[key] = streaks.get(key,0)+1 if score>=.5 else 0
    assert row['positive_streak'] == streaks[key]
    assert row['repeated_positive'] == (streaks[key]>=2)
    ref = (s['owner']==uid)&(s['batch']<n)
    assert row['baseline_pd_score'] == s['scores'][ref].mean()
    b = d['x'][(d['owner']==uid)&(d['batch']<n)].astype(float)
    x = d['x'][(d['owner']==uid)&(d['batch']==batch)].astype(float)
    bb = ((b[:,None]-b[None,:])**2).sum(-1)
    xx = ((x[:,None]-x[None,:])**2).sum(-1)
    bx = ((b[:,None]-x[None,:])**2).sum(-1)
    off = bb[~np.eye(len(b),dtype=bool)]
    positive = off[off>0]
    width = np.median(positive) if len(positive) else 1e-12
    mmd = max(0.,float(np.exp(-bb/width).mean()+np.exp(-xx/width).mean()-2*np.exp(-bx/width).mean()))
    np.testing.assert_allclose(row['mmd2'],mmd,atol=1e-12,rtol=0)

for a in result['aggregates']:
    mask = (s['split']==a['role'])&(s['batch']>=a['baseline_batches'])
    ids = np.unique(s['owner'][mask])
    scores = np.stack([s['scores'][mask&(s['owner']==uid)].mean(0) for uid in ids])
    y = np.array([s['y'][np.flatnonzero(s['owner']==uid)[0]] for uid in ids])
    accuracies = [accuracy_score(y, scores[:,i]>=.5) for i in range(25)]
    np.testing.assert_equal(a['mean_fold_accuracy'],np.mean(accuracies))
    np.testing.assert_equal(a['sd_fold_accuracy'],np.std(accuracies,ddof=1))
    np.testing.assert_equal(a['mean_fold_auroc'],np.mean([roc_auc_score(y,scores[:,i]) for i in range(25)]))
    assert a['people'] == len(ids) and a['followup_batches'] == mask.sum()
    assert a['person_ensemble']['accuracy'] == accuracy_score(y,scores.mean(1)>=.5)
    assert a['batch_ensemble']['accuracy'] == accuracy_score(s['y'][mask],s['scores'][mask].mean(1)>=.5)

with zipfile.ZipFile(p/'audit_source.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for name in ('/tmp/exp4_baseline_monitor_check.py','/tmp/exp4_baseline_monitor_audit.py'):
        z.write(name,Path(name).name)
write_json(p/'audit.json',dict(passed=True,models=25,batches=len(s['batch']),
    max_prediction_error=max_error,history_rows=len(rows),all_distances_recomputed=True,
    baseline_flags_independent_of_reference_size=True,metrics_recomputed=True,
    classifier_source_and_checkpoints_verified=True,
    scores_sha256=sha256(p/'scores.npz'),history_sha256=sha256(p/'history.json')))
print('Passed: all 25 classifiers, 1432 batch scores, both baseline histories/distances, frozen artifacts and evaluation metrics.')
