import ast
import json
import zipfile
from collections import Counter
from pathlib import Path
import joblib
import numpy as np
from sklearn.metrics import accuracy_score, roc_auc_score
from prototype_net.exp4.model import ROOT, MODELS, ROLES, SEED, sha256, split_indices, typenet_verify, write_json

out = ROOT / 'prototype_net/exp4/runs/real'
reg = typenet_verify(out)
with np.load(out / 'dataset.npz', allow_pickle=False) as cache:
    data = {key: cache[key] for key in cache.files}
assert not data['synthetic'].any()
assert len(data['y']) == 12916 and len(np.unique(data['owner'])) == 317
ids = np.unique(data['owner'])
labels = np.array([data['y'][np.flatnonzero(data['owner'] == uid)[0]] for uid in ids])
expected = split_indices(ids, labels, SEED)
for role in ROLES:
    assert reg['splits'][role] == ids[expected[role]].tolist()
    assert set(data['owner'][data['split'] == role]) == set(reg['splits'][role])
assert [len(reg['splits'][r]) for r in ROLES] == [221, 32, 64]
for repeat in range(1, 6):
    counter = Counter()
    for fold in [f for f in reg['folds'] if f['repeat'] == repeat]:
        fit, score = set(fold['fit']), set(fold['score'])
        assert not fit & score and fit | score == set(reg['splits']['train'])
        counter.update(fold['score'])
    assert set(counter) == set(reg['splits']['train']) and set(counter.values()) == {1}
for folder, cohort in [('typenet', 'neuroqwerty'), ('external', 'online')]:
    with np.load(out.parent / folder / 'dataset.npz') as source:
        keep = ~source['synthetic'] if 'synthetic' in source else np.ones(len(source['y']), dtype=bool)
        mask = data['cohort'] == cohort
        for key in ('x', 'owner', 'y'):
            assert np.array_equal(source[key][keep], data[key][mask])
with zipfile.ZipFile(out.parent / 'external/source.zip') as archive:
    old = ast.parse(archive.read('prototype_net/exp4/model.py'))
new = ast.parse((ROOT / 'prototype_net/exp4/model.py').read_text())
def definitions(tree):
    return {n.name: ast.dump(n, include_attributes=False) for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
a, b = definitions(old), definitions(new)
assert all(b[name] == value for name, value in a.items() if name != 'main')
print('Dataset, fresh split, folds, real-only feature provenance and unchanged training functions verified.', flush=True)
if not (out / 'results.json').exists():
    raise SystemExit(0)
freeze = json.loads((out / 'freeze.json').read_text())
assert len(freeze['models']) == 25
for record in freeze['models']:
    path = out / f"fold{record['index']:02d}.joblib"
    assert sha256(path) == record['sha256']
    bundle = joblib.load(path)
    mask = np.isin(data['owner'], bundle['fold']['fit'])
    x = data['x'][mask].astype(np.float64)
    for family in MODELS:
        model = bundle['models'][f'{family}_0']
        state = model['preprocess']
        assert model['real_rows'] == int(mask.sum()) == model['fit_rows']
        assert model['synthetic_rows'] == 0 and not model['parents']
        assert model['real_people'] == len(bundle['fold']['fit'])
        assert np.allclose(state['medians'], np.median(x, axis=0))
        assert np.allclose(state['scaler'].mean_, x.mean(0), rtol=1e-6, atol=1e-10)
        assert np.allclose(state['scaler'].var_, x.var(0), rtol=1e-6, atol=1e-10)
        assert state['scaler'].n_samples_seen_ == len(x)
        if family in ('node', 'tabnet'):
            assert model['epochs'] == 100
results = json.loads((out / 'results.json').read_text())
assert results['freeze_sha256'] == sha256(out / 'freeze.json')
assert results['predictions_sha256'] == sha256(out / 'predictions.npz')
with np.load(out / 'predictions.npz') as predictions:
    assert np.array_equal(predictions['ids'], ids) and np.array_equal(predictions['y'], labels)
    for aggregate in results['aggregates']:
        mask = predictions['split'] == aggregate['role']
        if aggregate['cohort'] != 'all':
            mask &= predictions['cohort'] == aggregate['cohort']
        y = predictions['y'][mask]
        p = predictions[aggregate['family']][:, mask]
        assert p.shape == (25, aggregate['people'])
        for key, scores in [('accuracy', [accuracy_score(y, row >= .5) for row in p]),
                            ('auroc', [roc_auc_score(y, row) for row in p])]:
            assert np.isclose(np.mean(scores), aggregate[key]['mean'])
            assert np.isclose(np.std(scores, ddof=1), aggregate[key]['sd'])
        assert np.isclose(accuracy_score(y, p.mean(0) >= .5), aggregate['ensemble']['accuracy'])
        assert np.isclose(roc_auc_score(y, p.mean(0)), aggregate['ensemble']['auroc'])
write_json(out / 'verification.json', dict(passed=True, fits=100, synthetic_rows=0,
    checks=['fresh reproducible participant split', 'five complete participant-disjoint CV repeats',
            'cached features exactly match real-only source observations', 'prior training functions unchanged',
            '100 scalers and imputers fit only corresponding CV training rows',
            'all model and encoder hashes unchanged', 'all participant accuracy, AUROC and sample SD reproduce',
            'all ensemble accuracy and AUROC reproduce'], audit_sha256=sha256(__file__)))
with zipfile.ZipFile(out / 'audit_source.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    archive.write(__file__, 'verify.py')
print('Full verification passed.', flush=True)
