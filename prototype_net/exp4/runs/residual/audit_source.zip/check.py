import ast, tempfile, zipfile
from pathlib import Path
import numpy as np
import torch
import joblib
from threadpoolctl import threadpool_limits
from prototype_net.exp4.model import ROOT,SEED,NODE,ResidualNODE,fit_residual,predict_residual

torch.set_num_threads(1)
threadpool_limits(limits=1)
with zipfile.ZipFile(ROOT/'prototype_net/exp4/runs/baseline_embeddings/source.zip') as z:
 old=ast.parse(z.read('prototype_net/exp4/model.py'))
new=ast.parse((ROOT/'prototype_net/exp4/model.py').read_text())
def defs(t):return {n.name:ast.dump(n) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=defs(old),defs(new)
assert all(b[k]==v for k,v in a.items() if k!='main')
rng=np.random.default_rng(SEED)
x=rng.normal(size=(80,128)).astype('float32')
base=rng.normal(size=(80,6,128)).astype('float32')
y=np.tile([0,1],40)
ids=np.repeat(np.array([f'p{i}' for i in range(20)]),4)
y=np.repeat(np.tile([0,1],10),4)
tx,tb=torch.from_numpy(x),torch.from_numpy(base)
torch.manual_seed(SEED)
control=NODE(128,2);control.initialize(tx)
torch.manual_seed(SEED)
residual=ResidualNODE('residual');residual.initialize(tx,tb)
assert all(torch.equal(v,residual.head.state_dict()[k]) for k,v in control.state_dict().items())
assert torch.equal(residual.representation(tx,tb),tx)
assert torch.equal(residual(tx,tb),control(tx)[0])
for mode in ('residual','late'):
 torch.manual_seed(SEED)
 m=ResidualNODE(mode)
 if mode=='residual':m.gate.data.fill_(.2)
 m.initialize(tx,tb)
 torch.testing.assert_close(m(tx,tb),m(tx,tb[:,torch.tensor([5,3,1,0,2,4])]),rtol=1e-5,atol=1e-6)
 assert not torch.allclose(m.representation(tx,tb),m.representation(tx,tb+2))
 loss=torch.nn.functional.cross_entropy(m(tx,tb),torch.tensor(y));loss.backward()
 assert m.query.weight.grad.norm()>0 and m.key.weight.grad.norm()>0
 assert m.correction[0].weight.grad.norm()>0 and m.head.layers[0].responses.grad.norm()>0
 model=fit_residual(x,base,y,ids,mode,3)
 p=predict_residual(model,x,base)
 assert np.isfinite(p).all() and ((p>=0)&(p<=1)).all()
 assert not np.allclose(p,predict_residual(model,x,base+2))
 with tempfile.TemporaryDirectory() as folder:
  path=Path(folder)/'model.joblib';joblib.dump(model,path)
  assert np.array_equal(p,predict_residual(joblib.load(path),x,base))
print('Passed: preserved old functions, exact initial residual/control equality, baseline-order invariance, baseline dependence, gradients through attention/correction/NODE, and trained checkpoint round trips.')
