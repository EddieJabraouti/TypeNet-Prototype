import ast,json,math,zipfile
from collections import Counter
from pathlib import Path
import joblib,numpy as np,torch
from sklearn.metrics import accuracy_score,roc_auc_score
from threadpoolctl import threadpool_limits
from prototype_net.exp4.model import ROOT,SEED,typenet_verify,sha256,write_json,predict_residual,ResidualNODE,preprocess

torch.set_num_threads(1);threadpool_limits(limits=1)
out=ROOT/'prototype_net/exp4/runs/residual';reg=typenet_verify(out)
source=ROOT/reg['source_dataset'];parent=source.parent.parent
old=json.loads((parent/'registration.json').read_text())
assert sha256(source)==reg['source_dataset_sha256']
assert sha256(parent/'registration.json')==reg['source_registration_sha256']
assert sha256(parent/'source.zip')==reg['source_archive_sha256']
assert sha256(parent/'events.npz')==old['events_sha256']
with zipfile.ZipFile(parent/'source.zip') as z:before=ast.parse(z.read('prototype_net/exp4/model.py'))
after=ast.parse((ROOT/'prototype_net/exp4/model.py').read_text())
def defs(tree):return {n.name:ast.dump(n) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=defs(before),defs(after);assert all(b[k]==v for k,v in a.items() if k!='main')
for key in ('splits','folds','counts'):assert reg[key]==old['scenarios']['300'][key]
assert reg['epochs']==100 and reg['seed']==SEED and reg['threshold']==.5
assert reg['modes']==['population','residual','late']
with np.load(out/'dataset.npz') as z:d={k:z[k] for k in z.files}
with np.load(source) as z:s={k:z[k] for k in z.files}
keep=s['batch']>0
assert d['x'].shape==(6726,128) and d['baseline'].shape==(6726,6,128)
assert np.isfinite(d['x']).all() and np.isfinite(d['baseline']).all()
for key in ('x','y','owner','split','batch','lineage'):assert np.array_equal(d[key],s[key][keep]),key
assert len(np.unique(s['lineage']))==s['lineage'].size
with np.load(parent/'events.npz') as z:events=z['events']
assert np.all(events[s['lineage'],0]==s['owner'][:,None])
for uid in np.unique(d['owner']):
 base=(s['owner']==uid)&(s['batch']==0);post=d['owner']==uid
 assert base.sum()==6
 assert np.array_equal(d['baseline'][post],np.broadcast_to(s['x'][base],d['baseline'][post].shape))
 base_ids=s['lineage'][base].ravel();post_ids=d['lineage'][post].ravel()
 assert not set(base_ids)&set(post_ids)
 def order(session):return int(session.split('.')[0]) if uid.startswith('nq:') else int(session.rsplit(':',1)[1])
 assert max(map(order,events[base_ids,1]))<=min(map(order,events[post_ids,1]))
 for session in set(events[base_ids,1])&set(events[post_ids,1]):
  assert events[base_ids[events[base_ids,1]==session],3].astype(float).max()<=events[post_ids[events[post_ids,1]==session],3].astype(float).min()
assert [len(reg['splits'][r]) for r in ('train','validation','test')]==[218,31,62]
assert len(set(sum(reg['splits'].values(),[])))==311
for repeat in range(1,6):
 c=Counter()
 for f in [f for f in reg['folds'] if f['repeat']==repeat]:
  fit,score=set(f['fit']),set(f['score']);assert not fit&score and fit|score==set(reg['splits']['train'])
  c.update(f['score'])
 assert set(c)==set(reg['splits']['train']) and set(c.values())=={1}
print('300-key data, full baseline provenance/chronology, preserved old functions and matched participant folds verified.',flush=True)
if not (out/'results.json').exists():raise SystemExit(0)
freeze=json.loads((out/'freeze.json').read_text());results=json.loads((out/'results.json').read_text())
assert len(freeze['models'])==25 and freeze['registration_sha256']==sha256(out/'registration.json')
assert results['freeze_sha256']==sha256(out/'freeze.json')
assert results['predictions_sha256']==sha256(out/'predictions.npz')
with np.load(out/'predictions.npz') as z:pred={k:z[k] for k in z.files}
assert np.array_equal(pred['ids'],np.unique(d['owner']))
old_freeze=json.loads((parent/'freeze.json').read_text());diagnostics=[]
for rec in freeze['models']:
 path=out/f"fold{rec['index']:02d}.joblib";assert sha256(path)==rec['sha256']
 bundle=joblib.load(path);assert bundle['registration_sha256']==freeze['registration_sha256']
 assert bundle['fold']==reg['folds'][rec['index']-1]
 assert set(bundle['models'])==set(reg['modes'])
 fit=np.isin(d['owner'],bundle['fold']['fit']);x=d['x'][fit].astype(float)
 oldpath=parent/'300'/path.name
 assert sha256(oldpath)==next(r['sha256'] for r in old_freeze['models'] if r['size']=='300' and r['index']==rec['index'])
 previous=joblib.load(oldpath)['models']['node_population']
 for mode,m in bundle['models'].items():
  assert m['epochs']==100 and m['batch_size']==512
  assert m['optimizer_updates']==100*math.ceil(len(x)/512)
  assert m['real_rows']==m['fit_rows']==len(x) and m['real_people']==len(bundle['fold']['fit']) and not m['parents']
  state=m['preprocess'];scale=state['scaler']
  assert scale.n_features_in_==128 and scale.n_samples_seen_==len(x)
  np.testing.assert_allclose(state['medians'],np.median(x,axis=0))
  np.testing.assert_allclose(scale.mean_,x.mean(0),rtol=1e-6,atol=1e-9)
  np.testing.assert_allclose(scale.var_,x.var(0),rtol=1e-6,atol=1e-9)
  if mode=='population':
   assert all(torch.equal(v,previous['state'][k]) for k,v in m['state'].items())
  else:
   net=ResidualNODE(mode);net.load_state_dict(m['state']);net.eval()
   assert m['parameter_changes']['query.weight']>0 and m['parameter_changes']['key.weight']>0
   tx,_=preprocess(d['x'][fit][:64],state)
   tb,_=preprocess(d['baseline'][fit][:64].reshape(-1,128),state)
   tx,tb=torch.from_numpy(tx),torch.from_numpy(tb.reshape(-1,6,128))
   with torch.inference_mode():
    output=net(tx,tb);permuted=net(tx,tb.flip(1))
    torch.testing.assert_close(output,permuted,rtol=1e-4,atol=1e-5)
    change=(output.softmax(-1)[:,1]-net(tx,torch.zeros_like(tb)).softmax(-1)[:,1]).abs().mean().item()
   diagnostics.append(dict(fold=rec['index'],mode=mode,training_baseline_zero_mean_probability_change=change))
   if mode=='residual':assert net.gate.norm().item()>0
  p=predict_residual(m,d['x'],d['baseline'])
  grouped=np.array([p[d['owner']==uid].mean() for uid in pred['ids']])
  np.testing.assert_allclose(grouped,pred[mode][rec['index']-1],rtol=1e-7,atol=1e-8)
 print('Verified fold',rec['index'],'all three checkpoints and predictions',flush=True)
for a in results['aggregates']:
 mask=pred['split']==a['role'];y=pred['y'][mask];p=pred[a['mode']][:,mask]
 assert p.shape==(25,a['people'])
 for key,values in [('accuracy',[accuracy_score(y,row>=.5) for row in p]),('auroc',[roc_auc_score(y,row) for row in p])]:
  assert np.isclose(np.mean(values),a[key]['mean']) and np.isclose(np.std(values,ddof=1),a[key]['sd'])
 assert np.isclose(accuracy_score(y,p.mean(0)>=.5),a['ensemble']['accuracy'])
 assert np.isclose(roc_auc_score(y,p.mean(0)),a['ensemble']['auroc'])
write_json(out/'verification.json',dict(passed=True,fits=75,keys=300,diagnostics=diagnostics,checks=[
 'original real follow-up embeddings and full same-person earlier baseline matrices',
 'no overlap of raw baseline and follow-up events', 'same participant splits and 25 CV folds',
 'all prior functions unchanged; all 25 fresh control checkpoints exactly reproduce previous NODE weights',
 'all 75 preprocessing states fit only CV training follow-up rows; same transform applied to baseline',
 '100 epochs and same optimizer update counts; attention/correction train jointly with NODE',
 'trained adapters invariant to baseline row permutation; residual gates moved from zero',
 'all 75 saved predictions reproduced from checkpoints', 'encoder, dataset and model hashes verified',
 'accuracy/AUROC/sample SD and ensembles independently reproduced'],audit_sha256=sha256(__file__)))
with zipfile.ZipFile(out/'audit_source.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 z.write(__file__,'verify.py');z.write('/tmp/exp4_residual_check.py','check.py')
print('Full residual verification passed.',flush=True)
