import ast,json,zipfile
from collections import Counter
from pathlib import Path
import joblib
import numpy as np
from sklearn.metrics import accuracy_score,roc_auc_score
from prototype_net.exp4.model import ROOT,personal_verify,sha256,write_json
out=ROOT/'prototype_net/exp4/runs/personal';reg=personal_verify(out)
original=json.loads((Path(reg['baseline_run'])/'registration.json').read_text())
with np.load(out/'events.npz') as a:events=a['events']
assert sha256(out/'events.npz')==reg['events_sha256']
with zipfile.ZipFile(out.parent/'impaired/source.zip') as z:old=ast.parse(z.read('prototype_net/exp4/model.py'))
new=ast.parse((ROOT/'prototype_net/exp4/model.py').read_text())
def defs(tree):return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=defs(old),defs(new);assert all(b[k]==v for k,v in a.items() if k!='main')
for size,s in reg['scenarios'].items():
 with np.load(out/size/'dataset.npz') as a:d={k:a[k] for k in a.files}
 assert np.isfinite(d['personal']).all() and np.isfinite(d['x']).all()
 assert len(np.unique(d['lineage']))==d['lineage'].size
 assert np.all(events[d['lineage'],0]==d['owner'][:,None])
 assert set(d['owner'])==set(sum(s['splits'].values(),[]))
 for role,ids in s['splits'].items():
  assert set(ids)<=set(original['splits'][role])
  assert set(d['owner'][d['split']==role])==set(ids)
 for uid in np.unique(d['owner']):
  base=(d['owner']==uid)&(d['batch']==0);post=(d['owner']==uid)&(d['batch']>0)
  assert base.sum()==s['windows_per_batch']
  reference=d['x'][base];mean=reference.mean(0);std=reference.std(0)
  for batch in np.unique(d['batch'][post]):
   mask=(d['owner']==uid)&(d['batch']==batch)
   assert mask.sum()==s['windows_per_batch']
   f=d['personal'][mask]
   assert np.array_equal(f[:,:135],d['x'][mask])
   assert np.allclose(f[:,135:270],mean[None,:])
   assert np.allclose(f[:,270:405],std[None,:])
   assert np.allclose(f[:,405:],(d['x'][mask]-mean)/np.where(std>1e-8,std,1.))
   # The final sequence of every batch has no timing input from future keys.
   assert np.array_equal(d['raw'][np.flatnonzero(mask)[-1],-1,1:4],np.zeros(3))
  base_ids=d['lineage'][base].ravel();post_ids=d['lineage'][post].ravel()
  assert not set(base_ids)&set(post_ids)
  base_sessions=set(events[base_ids,1]);post_sessions=set(events[post_ids,1])
  def order(session):return int(session.split('.')[0]) if uid.startswith('nq:') else int(session.rsplit(':',1)[1])
  assert max(map(order,base_sessions))<=min(map(order,post_sessions))
  if size=='400':assert not base_sessions&post_sessions and max(map(order,base_sessions))<min(map(order,post_sessions))
  for session in base_sessions&post_sessions:
   bp=events[base_ids[events[base_ids,1]==session],3].astype(float)
   pp=events[post_ids[events[post_ids,1]==session],3].astype(float)
   assert bp.max()<=pp.min()
 for repeat in range(1,6):
  c=Counter()
  for f in [f for f in s['folds'] if f['repeat']==repeat]:
   fit,score=set(f['fit']),set(f['score']);assert not fit&score and fit|score==set(s['splits']['train'])
   c.update(f['score'])
  assert set(c)==set(s['splits']['train']) and set(c.values())=={1}
 print(size,'data/chronology/folds verified',flush=True)
if not (out/'results.json').exists():raise SystemExit(0)
freeze=json.loads((out/'freeze.json').read_text());results=json.loads((out/'results.json').read_text())
assert len(freeze['models'])==50 and results['freeze_sha256']==sha256(out/'freeze.json')
for size,s in reg['scenarios'].items():
 with np.load(out/size/'dataset.npz') as a:d={k:a[k] for k in ('x','personal','owner','split','batch','y')}
 for record in [r for r in freeze['models'] if r['size']==size]:
  path=out/size/f"fold{record['index']:02d}.joblib";assert sha256(path)==record['sha256']
  bundle=joblib.load(path)
  mask=np.isin(d['owner'],bundle['fold']['fit'])&(d['batch']>0)
  for name,model in bundle['models'].items():
   x=d['personal'][mask] if name.endswith('_personal') else d['x'][mask]
   assert model['fit_rows']==mask.sum() and not model['parents']
   assert model['real_people']==len(bundle['fold']['fit'])
   state=model['preprocess'];scaler=state['scaler']
   assert scaler.n_samples_seen_==len(x)
   assert np.allclose(state['medians'],np.median(x,axis=0))
   assert np.allclose(scaler.mean_,x.astype(float).mean(0),atol=1e-9)
   assert np.allclose(scaler.var_,x.astype(float).var(0),atol=1e-9)
   assert x.shape[1]==(540 if name.endswith('_personal') else 135)
   if name.startswith('node'):assert model['epochs']==100
 r=results['scenarios'][size]
 assert sha256(out/size/'predictions.npz')==r['predictions_sha256']
 with np.load(out/size/'predictions.npz') as predictions:
  for a in r['aggregates']:
   mask=predictions['split']==a['role'];y=predictions['y'][mask]
   p=predictions[a['family']+'_'+a['arm']][:,mask]
   assert p.shape==(25,a['people'])
   for key,values in [('accuracy',[accuracy_score(y,row>=.5) for row in p]),('auroc',[roc_auc_score(y,row) for row in p])]:
    assert np.isclose(np.mean(values),a[key]['mean']) and np.isclose(np.std(values,ddof=1),a[key]['sd'])
   assert np.isclose(accuracy_score(y,p.mean(0)>=.5),a['ensemble']['accuracy'])
   assert np.isclose(roc_auc_score(y,p.mean(0)),a['ensemble']['auroc'])
write_json(out/'verification.json',dict(passed=True,fits=200,checks=['real event provenance and no reuse within either scenario',
 'baseline precedes follow-up; separate visits for 400 keys','no cross-batch successor timing in baseline',
 'personal features use only that participant earlier baseline statistics','participant assignments retained; identical folds across arms',
 '200 preprocessing states fit only their CV training follow-up rows','all checkpoint and encoder hashes unchanged',
 'all accuracy/AUROC/sample SD and ensembles reproduce','prior training and inference functions unchanged'],audit_sha256=sha256(__file__)))
with zipfile.ZipFile(out/'audit_source.zip','x',compression=zipfile.ZIP_DEFLATED) as z:z.write(__file__,'verify.py')
print('Full 300/400 verification passed.',flush=True)
