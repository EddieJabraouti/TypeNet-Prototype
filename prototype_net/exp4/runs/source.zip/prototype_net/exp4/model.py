"""Clinical keystroke experiments. Run with --help; protocol and sources in README.md."""
from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import zipfile
import argparse
import platform
import time
import subprocess
import shutil
import tempfile
from itertools import combinations
from concurrent.futures import ThreadPoolExecutor
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
import joblib
import sklearn
import torch
import xgboost
from scipy.stats import rankdata
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import (accuracy_score, average_precision_score, balanced_accuracy_score,
                             confusion_matrix, log_loss, mean_absolute_error, r2_score, roc_auc_score)
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits
from torch import nn
from torch.nn import functional as F

from prototype_net.failed.exp3.node import ObliviousLayer
from prototype_net.failed.exp3.tabnet import TabNet

ROOT = Path(__file__).resolve().parents[2]
SEED = 9172026
ROLES = ("train", "validation", "test")
MODELS = ("xgboost", "random_forest", "tabnet", "node")
STATS = ("mean", "sd", "q10", "median", "q90", "iqr", "skew")


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    with Path(path).open("x") as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write("\n")


def summary(values):
    a = np.asarray(values, dtype=float)
    a = a[np.isfinite(a)]
    if not len(a):
        return np.full(len(STATS), np.nan)
    q10, q25, med, q75, q90 = np.quantile(a, [.1, .25, .5, .75, .9])
    sd = a.std()
    skew = np.mean(((a - a.mean()) / sd) ** 3) if sd > 1e-12 else 0.
    return np.array([a.mean(), sd, q10, med, q90, q75 - q25, skew])


def neuroqwerty(base):
    ids, labels, targets, features, studies = [], [], [], [], []
    audit = Counter()
    source = base / "neuroqwerty/neuroQWERTY.zip"
    with zipfile.ZipFile(source) as z:
        for study in ("MIT-CS1PD", "MIT-CS2PD"):
            metadata = csv.DictReader(io.StringIO(z.read(f"{study}/GT_DataPD_{study}.csv").decode()))
            for person in metadata:
                holds = []
                for column, name in person.items():
                    if not column.startswith("file_") or not name:
                        continue
                    audit["recordings"] += 1
                    seen = set()
                    rows = csv.reader(io.StringIO(z.read(f"{study}/data_{study}/{name}").decode()))
                    for row in rows:
                        audit["raw_records"] += 1
                        try:
                            key = row[0]
                            if key.startswith("mouse"):
                                audit["mouse_records"] += 1
                                continue
                            hold, release, press = map(float, row[1:])
                            if not all(map(math.isfinite, (hold, release, press))) or not (hold > 0 and release >= press >= 0):
                                raise ValueError("invalid timing")
                            if abs(hold - (release - press)) > .001:
                                raise ValueError("timestamp mismatch")
                            token = (key, hold, release, press)
                            if token in seen:
                                audit["duplicate_records"] += 1
                                continue
                            seen.add(token)
                            holds.append(hold)
                        except (ValueError, IndexError):
                            audit["invalid_records"] += 1
                if not holds:
                    raise ValueError(f"No eligible data for {person['pID']}")
                if person["gt"] not in ("True", "False"):
                    raise ValueError("Unrecognized motor diagnosis")
                # Global pID protects against accidental cross-study duplicates.
                ids.append("nq:" + person["pID"])
                labels.append(int(person["gt"] == "True"))
                targets.append(float(person["updrs108"]))
                studies.append(study)
                features.append(summary(holds))
                audit["retained_records"] += len(holds)
    return dict(ids=ids, y=labels, updrs=targets, x=features, strata=studies,
                features=["hold_seconds_" + k for k in STATS], audit=dict(audit))


WRITING_FEATURES = (
    "time_on_task_s", "number_of_char_per_minute",
    "number_of_pauses_per_minute_PT30", "proportion_of_pause_time_PT2000",
    "number_of_P_bursts_per_minute_PB2000", "duration_of_P_bursts_s_PB2000",
    "pause_time_within_words_mean_s_PT30", "median_char_char",
)


def cognitive_label(value):
    if value.startswith("gezonde"):
        return 0
    if value in ("mci", "mild cognitive impairment", "Alzheimer"):
        return 1
    raise ValueError(f"Unknown cognitive diagnosis {value}")


def writing(base):
    folder = base / "ad_mci_writing"
    with (folder / "Participant_level.csv").open(encoding="latin1", newline="") as f:
        rows = list(csv.DictReader(f, delimiter=";"))
    with (folder / "Linguistic_analysis_word_level.csv").open(encoding="latin1", newline="") as f:
        words = list(csv.DictReader(f, delimiter=";"))
    people = defaultdict(list)
    for r in rows:
        people[r["participant_code"]].append(r)
    word_pauses = defaultdict(list)
    unmatched = Counter()
    for r in words:
        uid = r["Participant"]
        if uid not in people:
            unmatched[uid] += 1
            continue
        if cognitive_label(r["Group1"]) != cognitive_label(people[uid][0]["group1"]):
            raise ValueError(f"Conflicting binary diagnosis for {uid}")
        if r["Task"] not in {p["task"] for p in people[uid]}:
            raise ValueError(f"Unmatched task for {uid}")
        try:
            pause = float(r["BetweenWords"])
            if math.isfinite(pause) and pause >= 0:
                word_pauses[uid].append(pause)
        except ValueError:
            pass
    ids, x, y = [], [], []
    for uid, tasks in sorted(people.items()):
        labels = {cognitive_label(t["group1"]) for t in tasks}
        if len(labels) != 1 or len({t["task"] for t in tasks}) != len(tasks):
            raise ValueError(f"Duplicate task or conflicting diagnosis for {uid}")
        values = np.asarray([[float(t[k]) if t[k].strip() else np.nan for k in WRITING_FEATURES] for t in tasks])
        if np.isinf(values).any():
            raise ValueError("Invalid released writing summary")
        means = [np.mean(c[np.isfinite(c)]) if np.isfinite(c).any() else np.nan for c in values.T]
        x.append([*means, np.mean(word_pauses[uid]) if word_pauses[uid] else np.nan])
        ids.append("writing:" + uid)
        y.append(labels.pop())
    return dict(ids=ids, x=x, y=y, features=[*WRITING_FEATURES, "between_words_mean_ms"],
                audit=dict(participant_task_rows=len(rows), word_rows=len(words),
                           matched_word_pause_rows=sum(map(len, word_pauses.values())),
                           unmatched_word_ids=dict(unmatched),
                           note="Exact-ID joins only; task means per person; word pauses pooled per person. Age bands are not used."))


def tappy(base):
    """All available monthly files; exact record union per stable participant ID."""
    folder = base / "tappy"
    metadata = {}
    conflicts = set()
    user_archives = [folder / "Archived-users.zip", *sorted((folder / "expanded").glob("*sers*.zip"))]
    for path in user_archives:
        with zipfile.ZipFile(path) as z:
            for name in z.namelist():
                if not name.endswith(".txt") or Path(name).name.startswith("._"):
                    continue
                uid = Path(name).stem.removeprefix("User_")
                info = dict(line.split(": ", 1) for line in z.read(name).decode(errors="replace").splitlines() if ": " in line)
                label = info.get("Parkinsons")
                if label not in ("True", "False"):
                    continue
                if uid in metadata and metadata[uid] != label:
                    conflicts.add(uid)
                metadata[uid] = label
    archives = [folder / "Archived-Data.zip", *sorted((folder / "expanded").glob("*Data*.zip"))]
    audit = Counter()
    ids, labels, features = [], [], []
    # Read one participant at a time: bounded memory even for expanded releases.
    handles = [zipfile.ZipFile(path) for path in archives]
    try:
        files = defaultdict(list)
        for z in handles:
            for name in z.namelist():
                if name.endswith(".txt") and not Path(name).name.startswith("._"):
                    files[Path(name).stem.split("_")[0]].append((z, name))
        for index, (uid, members) in enumerate(sorted(files.items())):
            if uid not in metadata or uid in conflicts:
                audit["excluded_unlabeled_or_conflicting_people"] += 1
                continue
            records = set()
            for z, name in members:
                with z.open(name) as f:
                    for line in f:
                        audit["raw_labeled_records"] += 1
                        try:
                            r = line.decode(errors="replace").strip().split("\t")
                            if len(r) < 8:
                                r = line.decode(errors="replace").strip().split(",")
                            h, latency, flight = (float(r[j]) for j in (4, 6, 7))
                            if r[0] != uid or r[3] not in ("L", "R", "S") or not all(map(math.isfinite, (h, latency, flight))) or h <= 0 or latency <= 0:
                                raise ValueError("invalid timing")
                            # No sequence reconstruction; dates are only deduplication keys.
                            token = (r[1], r[2], r[3], r[5], h, latency, flight)
                            if token in records:
                                audit["duplicate_records"] += 1
                            records.add(token)
                        except (ValueError, IndexError):
                            audit["invalid_records"] += 1
            if records:
                values = np.asarray([r[4:] for r in sorted(records)], dtype=float) / 1000.
                features.append(np.concatenate([summary(values[:, j]) for j in range(3)]))
                ids.append("tappy:" + uid)
                labels.append(int(metadata[uid] == "True"))
                audit["retained_records"] += len(records)
            if index % 50 == 0:
                print(f"Tappy: {index + 1}/{len(files)} identities processed", flush=True)
    finally:
        for z in handles:
            z.close()
    return dict(ids=ids, y=labels, x=features,
                features=[f"{timing}_seconds_{s}" for timing in ("hold", "latency", "flight") for s in STATS],
                audit={**audit, "conflicting_label_ids": sorted(conflicts), "record_archives": [str(p.relative_to(ROOT)) for p in archives]})


def split_indices(ids, labels, seed=SEED):
    """One participant is one row. Shared by all models and descendants."""
    ids, labels = np.asarray(ids), np.asarray(labels)
    if len(set(ids)) != len(ids):
        raise ValueError("Participant IDs must be unique")
    indexes = np.arange(len(ids))
    trainval, test = train_test_split(indexes, test_size=.2, stratify=labels, random_state=seed)
    train, validation = train_test_split(trainval, test_size=.125, stratify=labels[trainval], random_state=seed)
    result = dict(train=np.sort(train), validation=np.sort(validation), test=np.sort(test))
    assert len(set(np.concatenate(list(result.values())))) == len(ids)
    return result


def prepare(out, base=None):
    base = base or ROOT / "data/clinical"
    out.mkdir(parents=True, exist_ok=False)
    (out / "README.md").write_bytes((Path(__file__).parent / "README.md").read_bytes())
    sources = sorted(base.rglob("*.zip*")) + sorted((base / "ad_mci_writing").glob("*.csv"))
    source_hashes = {str(p.relative_to(ROOT)): sha256(p) for p in sources}
    cohorts = {"motor_pd": neuroqwerty(base), "cognitive_ci": writing(base), "tappy_self_report": tappy(base)}
    manifest = dict(seed=SEED, target_fractions=[.7, .1, .2],
                    rounding="ceil(0.20*N) test, ceil(0.125*remaining) validation; rest train",
                    source_hashes=source_hashes, cohorts={}, tasks={})
    for name, cohort in cohorts.items():
        roles = split_indices(cohort["ids"], cohort["y"])
        ids = np.asarray(cohort["ids"])
        x, y = np.asarray(cohort["x"], dtype=np.float64), np.asarray(cohort["y"], dtype=int)
        if np.isinf(x).any():
            raise ValueError("Infinite clinical feature")
        info = dict(features=cohort["features"], audit=cohort["audit"], splits={r: ids[i].tolist() for r, i in roles.items()},
                    counts={r: dict(participants=len(i), positive=int(y[i].sum()), fraction=len(i)/len(ids)) for r, i in roles.items()})
        manifest["cohorts"][name] = info
        endpoints = [(name, y, "classification")]
        if name == "motor_pd":
            endpoint = np.asarray(cohort["updrs"], dtype=float)
            if not np.isfinite(endpoint).all() or (endpoint < 0).any() or (endpoint > 108).any():
                raise ValueError("Invalid UPDRS-III label")
            endpoints.append(("motor_updrs", endpoint, "regression"))
        for task, target, kind in endpoints:
            taskdir = out / task
            taskdir.mkdir()
            hashes = {}
            for role, ix in roles.items():
                p = taskdir / f"{role}.npz"
                np.savez_compressed(p, x=x[ix], y=target[ix], ids=ids[ix],
                                    diagnosis=y[ix], features=np.asarray(cohort["features"]))
                hashes[role] = sha256(p)
            manifest["tasks"][task] = dict(cohort=name, kind=kind, cache_sha256=hashes)
    inventory = {}
    for name in ("Keystrokes", "keystrokes_f"):
        paths = sorted((ROOT / "data" / name / "files").glob("*"))
        inventory[name] = dict(files=len(paths), bytes=sum(p.stat().st_size for p in paths if p.is_file()),
                               role="unlabeled; excluded from clinical supervised targets", clinical_labels=False)
    manifest["unlabeled_inventory"] = inventory
    write_json(out / "manifest.json", manifest)
    print(json.dumps({k: v["counts"] for k, v in manifest["cohorts"].items()}, indent=2))
    return manifest


def fetch_tappy():
    folder = ROOT / "data/clinical/tappy/expanded"
    folder.mkdir(parents=True, exist_ok=True)
    url = "https://data.mendeley.com/public-api/datasets/z39mhdsynx/files?folder_id=root&version=3"
    manifest_path = folder / "download.json"
    if not manifest_path.exists():
        subprocess.run(["curl", "-fsSL", "--max-time", "60", "-H",
                        "Accept: application/vnd.mendeley-public-dataset.1+json", url, "-o", str(manifest_path)], check=True)
    listing = json.loads(manifest_path.read_text())
    archive = folder / "Archived Data.zip"
    if archive.exists():
        with zipfile.ZipFile(archive) as z:
            if z.testzip() is not None:
                raise ValueError("Expanded archive checksum failed")
        return
    parts = []
    for item in sorted(listing, key=lambda r: r["filename"]):
        name = item["filename"]
        if Path(name).name != name:
            raise ValueError("Unsafe archive filename")
        path = folder / name
        details = item["content_details"]
        if not path.exists() or sha256(path) != details["sha256_hash"]:
            temporary = path.with_suffix(path.suffix + ".part")
            subprocess.run(["curl", "-fL", "--retry", "3", "--max-time", "300",
                            details["download_url"], "-o", str(temporary)], check=True)
            if sha256(temporary) != details["sha256_hash"]:
                raise ValueError(f"Download hash mismatch: {name}")
            temporary.replace(path)
        if name.startswith("Archived Data.zip."):
            parts.append(path)
        print(f"Verified {name}", flush=True)
    combined = archive.with_suffix(".part")
    with combined.open("wb") as f:
        for p in parts:
            with p.open("rb") as source:
                shutil.copyfileobj(source, f)
    with zipfile.ZipFile(combined) as z:
        if z.testzip() is not None:
            raise ValueError("Expanded archive checksum failed")
    combined.replace(archive)
    for p in parts:
        p.unlink()


def preprocess(x, state=None):
    if state is None:
        medians = np.array([np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0. for c in x.T])
        filled = np.where(np.isnan(x), medians, x)
        scaler = StandardScaler().fit(filled)
        state = dict(medians=medians, scaler=scaler)
    transformed = state["scaler"].transform(np.where(np.isnan(x), state["medians"], x)).astype(np.float32)
    if not np.isfinite(transformed).all():
        raise ValueError("Nonfinite transformed features")
    return transformed, state


def aalto_person(path):
    uid = path.stem.removesuffix("_keystrokes")
    columns = ["PARTICIPANT_ID", "KEYSTROKE_ID", "PRESS_TIME", "RELEASE_TIME"]
    alternate = ROOT / "data/keystrokes_f/files" / path.name
    choices = [path] + ([alternate] if alternate != path and alternate.exists() else [])
    status = "primary"
    for candidate in choices:
        raw = candidate.read_bytes()
        if not all(c.encode() in raw.split(b"\n", 1)[0] for c in columns):
            continue
        data = pd.read_csv(io.BytesIO(raw), sep="\t", quoting=csv.QUOTE_NONE, encoding="latin1", usecols=columns)
        status = "fallback" if candidate != path else "primary"
        break
    else:
        return uid, np.full(7, np.nan), 0, 0, hashlib.sha256(raw).hexdigest(), "unreadable_header"
    count = len(data)
    person = pd.to_numeric(data["PARTICIPANT_ID"], errors="coerce")
    event = pd.to_numeric(data["KEYSTROKE_ID"], errors="coerce")
    data = data[(person == int(uid)) & np.isfinite(event)].copy()
    data = data.drop_duplicates("KEYSTROKE_ID")
    holds = (pd.to_numeric(data["RELEASE_TIME"], errors="coerce") - pd.to_numeric(data["PRESS_TIME"], errors="coerce")) / 1000.
    valid = holds[np.isfinite(holds) & (holds > 0)].to_numpy()
    return uid, summary(valid), count, len(valid), hashlib.sha256(raw).hexdigest(), status


def prepare_aalto(out):
    if (out / "registration.json").exists():
        raise ValueError("Cannot alter external data after registration")
    if not (out / "manifest.json").exists():
        raise ValueError("Run prepare first")
    path = out / "aalto.npz"
    if path.exists():
        raise FileExistsError(path)
    files = {}
    for folder in ("Keystrokes", "keystrokes_f"):
        for p in sorted((ROOT / "data" / folder / "files").glob("*_keystrokes.txt")):
            if not p.name.startswith("._"):
                files.setdefault(p.name, p)
    rows = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        paths = list(files.values())
        for start in range(0, len(paths), 2000):
            rows.extend(pool.map(aalto_person, paths[start:start+2000]))
            print(f"Aalto: {min(start+2000, len(paths))}/{len(paths)} people", flush=True)
    eligible = [r for r in rows if np.isfinite(r[1]).all()]
    np.savez_compressed(path, ids=np.asarray([r[0] for r in eligible]), x=np.asarray([r[1] for r in eligible]),
                        file_sha256=np.asarray([r[4] for r in eligible]),
                        raw_records=np.asarray([r[2] for r in eligible]), retained_records=np.asarray([r[3] for r in eligible]))
    write_json(out / "aalto.json", dict(source_files=len(files), eligible_people=len(eligible),
                                       excluded_people=[r[0] for r in rows if not np.isfinite(r[1]).all()],
                                       recovered_from_secondary=[r[0] for r in rows if r[5] == "fallback"],
                                       unreadable_header=[r[0] for r in rows if r[5] == "unreadable_header"],
                                       raw_records=sum(r[2] for r in rows), retained_records=sum(r[3] for r in rows),
                                       sha256=sha256(path), labels="none", source_priority=["Keystrokes", "keystrokes_f"]))


def pretrain(out):
    path = out / "encoder.joblib"
    if path.exists():
        value = joblib.load(path)
        if value["registration_sha256"] != sha256(out / "registration.json"):
            raise ValueError("Encoder registration changed")
        return value
    with np.load(out / "aalto.npz", allow_pickle=False) as data:
        x, state = preprocess(data["x"])
    torch.manual_seed(SEED)
    torch.use_deterministic_algorithms(True)
    model = neural_model("tabnet", 7, 7)
    model.initialize(torch.from_numpy(x))
    optimizer = torch.optim.AdamW(model.parameters(), lr=.003, weight_decay=1e-4)
    rng = np.random.default_rng(SEED)
    for epoch in range(10):
        losses = []
        for indexes in np.array_split(rng.permutation(len(x)), max(1, len(x)//512)):
            target = torch.from_numpy(x[indexes])
            mask = torch.rand_like(target) < .2
            optimizer.zero_grad()
            prediction, penalty = model(target.masked_fill(mask, 0.))
            loss = ((prediction-target).square() * mask).sum() / mask.sum().clamp_min(1) + .001*penalty
            if not torch.isfinite(loss):
                raise ValueError("Nonfinite reconstruction loss")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.)
            optimizer.step()
            losses.append(float(loss.detach()))
        print(f"Aalto pretraining {epoch+1}/10: masked MSE {np.mean(losses):.5f}", flush=True)
    value = dict(preprocess=state, state=model.state_dict(), registration_sha256=sha256(out / "registration.json"), people=len(x))
    joblib.dump(value, path, compress=3)
    return value


def embedding(encoder, raw):
    x, _ = preprocess(raw[:, :7], encoder["preprocess"])
    network = neural_model("tabnet", 7, 7)
    network.load_state_dict(encoder["state"])
    network.head = nn.Identity()
    network.eval()
    with torch.no_grad():
        return network(torch.from_numpy(x))[0].numpy()


def augment(x, y, ids, seed=SEED):
    rng = np.random.default_rng(seed)
    target = 2 * max(np.bincount(y))
    extra, targets, parents = [], [], []
    for label in np.unique(y):
        indexes = np.flatnonzero(y == label)
        if len(indexes) < 2:
            raise ValueError("SMOTE requires two real people per class")
        a = x[indexes].astype(float)
        distances = ((a[:, None] - a[None]) ** 2).sum(-1)
        np.fill_diagonal(distances, np.inf)
        neighbors = np.argsort(distances, axis=1, kind="stable")[:, :min(5, len(a) - 1)]
        for _ in range(target - len(a)):
            i = int(rng.integers(len(a)))
            j = int(rng.choice(neighbors[i]))
            weight = float(rng.random())
            extra.append(a[i] + weight * (a[j] - a[i]))
            targets.append(label)
            parents.append([str(ids[indexes[i]]), str(ids[indexes[j]]), weight])
    return np.concatenate([x, np.asarray(extra, dtype=np.float32)]), np.concatenate([y, targets]), parents


class NODE(nn.Module):
    def __init__(self, features, outputs):
        super().__init__()
        self.layers = nn.ModuleList([ObliviousLayer(features + i * 16 * outputs, 16, 3, outputs) for i in range(2)])

    @torch.no_grad()
    def initialize(self, x):
        for layer in self.layers:
            layer.initialize(x)
            x = torch.cat([x, layer(x).flatten(1)], dim=1)

    def forward(self, x):
        values = []
        for layer in self.layers:
            value = layer(x)
            values.append(value)
            x = torch.cat([x, value.flatten(1)], dim=1)
        return torch.cat(values, dim=1).mean(1), x.new_zeros(())


def neural_model(name, features, outputs):
    if name == "node":
        return NODE(features, outputs)
    model = TabNet(features=features, decision=8, attention=8, steps=3)
    model.head = nn.Linear(8, outputs, bias=False)
    return model


def fit_model(name, x, y, ids, kind, augmentation, epochs, encoder=None):
    x, state = preprocess(x)
    parents = []
    if augmentation == "smote":
        if kind != "classification":
            raise ValueError("Synthetic clinical severity labels are prohibited")
        x, y, parents = augment(x, y, ids)
    if encoder is not None:
        x = np.concatenate([x, embedding(encoder, state["scaler"].inverse_transform(x))], axis=1)
    result = dict(name=name, kind=kind, preprocess=state, encoder=encoder, parents=parents, real_people=len(ids), fit_rows=len(y))
    if name == "dummy":
        result["constant"] = float(np.mean(y))
    elif name in ("xgboost", "random_forest"):
        if name == "xgboost":
            cls = xgboost.XGBClassifier if kind == "classification" else xgboost.XGBRegressor
            model = cls(n_estimators=150, max_depth=2, learning_rate=.03, min_child_weight=3,
                        reg_lambda=10, subsample=1., colsample_bytree=1., tree_method="hist",
                        n_jobs=1, random_state=SEED)
        else:
            cls = RandomForestClassifier if kind == "classification" else RandomForestRegressor
            model = cls(n_estimators=300, max_depth=4, min_samples_leaf=3, max_features=1., n_jobs=1, random_state=SEED)
        result["estimator"] = model.fit(x, y)
    else:
        torch.manual_seed(SEED)
        torch.use_deterministic_algorithms(True)
        model = neural_model(name, x.shape[1], 2 if kind == "classification" else 1)
        tensor = torch.from_numpy(x)
        model.initialize(tensor)
        center = float(y.mean()) if kind == "regression" else 0.
        scale = max(float(y.std()), 1.) if kind == "regression" else 1.
        target = torch.tensor(y, dtype=torch.long) if kind == "classification" else torch.tensor((y-center)/scale, dtype=torch.float32)
        optimizer = torch.optim.AdamW(model.parameters(), lr=.003, weight_decay=1e-4)
        model.train()
        for _ in range(epochs):
            optimizer.zero_grad()
            output, penalty = model(tensor)
            loss = F.cross_entropy(output, target) if kind == "classification" else F.mse_loss(output[:, 0], target)
            loss = loss + (.001 * penalty if name == "tabnet" else 0.)
            if not torch.isfinite(loss):
                raise ValueError("Nonfinite training loss")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.)
            optimizer.step()
        result.update(state=model.state_dict(), features=x.shape[1], target_center=center, target_scale=scale)
    return result


def predict(model, x):
    raw = x
    x, _ = preprocess(raw, model["preprocess"])
    if model.get("encoder") is not None:
        x = np.concatenate([x, embedding(model["encoder"], model["preprocess"]["scaler"].inverse_transform(x))], axis=1)
    if "constant" in model:
        return np.full(len(x), model["constant"])
    classification = model["kind"] == "classification"
    if "estimator" in model:
        return model["estimator"].predict_proba(x)[:, 1] if classification else model["estimator"].predict(x)
    network = neural_model(model["name"], model["features"], 2 if classification else 1)
    network.load_state_dict(model["state"])
    network.eval()
    with torch.no_grad():
        output, _ = network(torch.from_numpy(x))
    return output.softmax(-1)[:, 1].numpy() if classification else output[:, 0].numpy() * model["target_scale"] + model["target_center"]


def metrics(y, prediction, kind):
    if prediction.shape != y.shape or not np.isfinite(prediction).all():
        raise ValueError("Invalid predictions")
    if kind == "regression":
        return dict(mae=float(mean_absolute_error(y, prediction)),
                    rmse=float(np.sqrt(np.mean((y-prediction)**2))), r2=float(r2_score(y, prediction)))
    if ((prediction < 0) | (prediction > 1)).any():
        raise ValueError("Invalid class probability")
    tn, fp, fn, tp = confusion_matrix(y, prediction >= .5, labels=[0, 1]).ravel()
    return dict(auroc=float(roc_auc_score(y, prediction)), average_precision=float(average_precision_score(y, prediction)),
                accuracy=float(accuracy_score(y, prediction >= .5)), balanced_accuracy=float(balanced_accuracy_score(y, prediction >= .5)),
                sensitivity=float(tp/(tp+fn)), specificity=float(tn/(tn+fp)),
                log_loss=float(log_loss(y, prediction, labels=[0, 1])), confusion_matrix=[[int(tn), int(fp)], [int(fn), int(tp)]])


def intervals(y, prediction, kind, baseline=None):
    rng = np.random.default_rng(SEED)
    draws = []
    for _ in range(2000):
        if kind == "classification":
            ix = np.concatenate([rng.choice(np.flatnonzero(y == c), np.sum(y == c), replace=True) for c in (0, 1)])
            labels, scores = y[ix], prediction[ix]
            ranks = rankdata(scores)
            positives = labels == 1
            n = int(positives.sum())
            value = (ranks[positives].sum() - n*(n+1)/2)/(n*(len(ix)-n))
        else:
            ix = rng.integers(len(y), size=len(y))
            value = np.mean(abs(y[ix] - prediction[ix]))
            if baseline is not None:
                value = np.mean(abs(y[ix]-baseline[ix])) - value
        draws.append(float(value))
    return dict(ci95=np.quantile(draws, [.025, .975]).tolist(), ci975=np.quantile(draws, [.0125, .9875]).tolist())


def permutation_p(y, prediction):
    ranks = rankdata(prediction)
    positives = int(y.sum())
    observed = ranks[y == 1].sum()
    count = math.comb(len(y), positives)
    if count <= 20000:
        return sum(ranks[list(ix)].sum() >= observed for ix in combinations(range(len(y)), positives)) / count
    rng = np.random.default_rng(SEED)
    exceed = sum(ranks[rng.choice(len(y), positives, replace=False)].sum() >= observed for _ in range(10000))
    return (1 + exceed) / 10001


def source_hashes():
    paths = [Path(__file__), ROOT / "prototype_net/failed/exp3/node.py", ROOT / "prototype_net/failed/exp3/tabnet.py"]
    return {str(p.relative_to(ROOT)): sha256(p) for p in paths}


def load_role(out, manifest, task, role):
    path = out / task / f"{role}.npz"
    info = manifest["tasks"][task]
    if sha256(path) != info["cache_sha256"][role]:
        raise ValueError(f"Changed feature cache: {task}/{role}")
    with np.load(path, allow_pickle=False) as z:
        values = {k: z[k] for k in z.files}
    expected = manifest["cohorts"][info["cohort"]]["splits"][role]
    if list(values["ids"]) != expected:
        raise ValueError("Participant order mismatch")
    return values


def train(out, epochs):
    manifest = json.loads((out / "manifest.json").read_text())
    if (out / "evaluation_opened.json").exists() or (out / "freeze.json").exists():
        raise ValueError("This experiment is sealed; training cannot resume")
    if not (out / "registration.json").exists():
        (out / "README.md").write_bytes(Path(__file__).with_name("README.md").read_bytes())
    registration = dict(seed=SEED, epochs=epochs, models=list(MODELS), augmentations=["none", "smote"],
                        threshold=.5, folds=3, selection="training OOF AUROC; regression minimum MAE; lexical tie break",
                        source_hashes=source_hashes(), manifest_sha256=sha256(out / "manifest.json"),
                        protocol_sha256=sha256(out / "README.md"),
                        aalto_sha256=sha256(out / "aalto.npz") if (out / "aalto.npz").exists() else None,
                        environment=dict(python=platform.python_version(), numpy=np.__version__, pandas=pd.__version__, sklearn=sklearn.__version__,
                                         torch=torch.__version__, xgboost=xgboost.__version__, joblib=joblib.__version__),
                        gate="Training-selected primary classifier: test AUROC 97.5% bootstrap lower bound > 0.5 and one-sided label-permutation p <= .025. Two primary endpoints; exploratory only.")
    path = out / "registration.json"
    if path.exists():
        if json.loads(path.read_text()) != registration:
            raise ValueError("Registered protocol changed")
    else:
        write_json(path, registration)
    selected, artifacts = {}, {}
    encoder = pretrain(out) if registration["aalto_sha256"] else None
    if encoder is not None:
        artifacts["encoder.joblib"] = sha256(out / "encoder.joblib")
    for task, info in manifest["tasks"].items():
        data = load_role(out, manifest, task, "train")
        x, y, ids, kind = data["x"], data["y"], data["ids"], info["kind"]
        folds = list(StratifiedKFold(3, shuffle=True, random_state=SEED).split(x, data["diagnosis"]))
        fold_ids = [{"fit": ids[a].tolist(), "score": ids[b].tolist()} for a, b in folds]
        representations = ("raw", "pretrained") if encoder is not None and info["cohort"] != "cognitive_ci" else ("raw",)
        candidates = [("dummy", "none", "raw")] + [(m, a, r) for m in MODELS for a in (("none", "smote") if kind == "classification" else ("none",)) for r in representations]
        results = {}
        for name, augmentation, representation in candidates:
            candidate = f"{name}_{augmentation}_{representation}"
            auxiliary = encoder if representation == "pretrained" else None
            checkpoint = out / task / f"{candidate}.joblib"
            if checkpoint.exists():
                item = joblib.load(checkpoint)
                if item["registration_sha256"] != sha256(path) or item["folds"] != fold_ids:
                    raise ValueError("Checkpoint provenance mismatch")
            else:
                started = time.monotonic()
                oof = np.empty(len(y))
                for fit, score in folds:
                    assert not set(ids[fit]) & set(ids[score])
                    model = fit_model(name, x[fit], y[fit], ids[fit], kind, augmentation, epochs, auxiliary)
                    assert all(a in ids[fit] and b in ids[fit] for a, b, _ in model["parents"])
                    oof[score] = predict(model, x[score])
                model = fit_model(name, x, y, ids, kind, augmentation, epochs, auxiliary)
                item = dict(model=model, oof=oof, training_oof=metrics(y, oof, kind), training_fit=metrics(y, predict(model, x), kind),
                            folds=fold_ids, registration_sha256=sha256(path), seconds=time.monotonic()-started)
                temporary = checkpoint.with_suffix(".tmp")
                joblib.dump(item, temporary, compress=3)
                temporary.replace(checkpoint)
                print(task, candidate, item["training_oof"], flush=True)
            results[candidate] = item["training_oof"]
            artifacts[str(checkpoint.relative_to(out))] = sha256(checkpoint)
        eligible = [k for k in results if not k.startswith("dummy_")]
        selected[task] = min(eligible, key=lambda k: (-results[k]["auroc"] if kind == "classification" else results[k]["mae"], k))
    write_json(out / "freeze.json", dict(registration_sha256=sha256(path), selected=selected, artifacts=artifacts))


def evaluate(out):
    manifest = json.loads((out / "manifest.json").read_text())
    registration = json.loads((out / "registration.json").read_text())
    freeze = json.loads((out / "freeze.json").read_text())
    if source_hashes() != registration["source_hashes"] or sha256(out / "manifest.json") != registration["manifest_sha256"]:
        raise ValueError("Source or manifest changed after registration")
    if sha256(out / "registration.json") != freeze["registration_sha256"]:
        raise ValueError("Registration changed after freeze")
    if sha256(out / "README.md") != registration["protocol_sha256"]:
        raise ValueError("Registered protocol document changed")
    for name, digest in freeze["artifacts"].items():
        if sha256(out / name) != digest:
            raise ValueError(f"Changed model: {name}")
    write_json(out / "evaluation_opened.json", dict(freeze_sha256=sha256(out / "freeze.json"), opened_at=time.time()))
    report = dict(selected=freeze["selected"], tasks={}, credibility={})
    for task, info in manifest["tasks"].items():
        kind = info["kind"]
        report["tasks"][task] = {}
        for role in ("validation", "test"):
            data = load_role(out, manifest, task, role)
            result = {}
            predictions = dict(ids=data["ids"], y=data["y"])
            for name in sorted(freeze["artifacts"]):
                if Path(name).parent.name != task:
                    continue
                candidate = Path(name).stem
                item = joblib.load(out / name)
                prediction = predict(item["model"], data["x"])
                predictions[candidate] = prediction
                result[candidate] = dict(**metrics(data["y"], prediction, kind), uncertainty=intervals(data["y"], prediction, kind))
            report["tasks"][task][role] = result
            np.savez_compressed(out / task / f"{role}_predictions.npz", **predictions)
            if role == "test":
                chosen = freeze["selected"][task]
                if kind == "classification":
                    pvalue = permutation_p(data["y"], predictions[chosen])
                    credible = result[chosen]["uncertainty"]["ci975"][0] > .5 and pvalue <= .025
                    report["credibility"][task] = dict(exploratory_signal=bool(credible), independent_test_people=len(data["y"]),
                                                     permutation_p=pvalue, clinical_ground_truth=task != "tappy_self_report", clinical_validation=False)
                else:
                    report["credibility"][task] = dict(mae_improvement_over_mean=intervals(data["y"], predictions[chosen], kind, predictions["dummy_none_raw"]), clinical_validation=False)
        print(f"Evaluated {task}; training-selected: {freeze['selected'][task]}", flush=True)
    report["request_data"] = not all(report["credibility"][t]["exploratory_signal"] for t in ("motor_pd", "cognitive_ci"))
    write_json(out / "results.json", report)
    print(json.dumps(report["credibility"], indent=2))


def check():
    """Synthetic-only checks; never opens clinical validation or test files."""
    rng = np.random.default_rng(SEED)
    x = rng.normal(size=(60, 7))
    y = np.tile([0, 1], 30)
    ids = np.array([f"person{i}" for i in range(60)])
    roles = split_indices(ids, y)
    assert [len(roles[r]) for r in ROLES] == [42, 6, 12]
    assert all(np.array_equal(roles[r], split_indices(ids, y)[r]) for r in ROLES)
    fit, score = roles["train"], roles["test"]
    transformed, state = preprocess(x[fit])
    shifted, _ = preprocess(x[score] + 1e6, state)
    assert abs(shifted.mean()) > 1e5 and np.allclose(transformed.mean(0), 0, atol=1e-6)
    sx, sy, parents = augment(transformed, y[fit], ids[fit])
    assert np.bincount(sy).tolist() == [42, 42]
    for row, (left, right, weight) in zip(sx[len(fit):], parents):
        assert left in ids[fit] and right in ids[fit] and left != right
        a, b = transformed[np.flatnonzero(ids[fit] == left)[0]], transformed[np.flatnonzero(ids[fit] == right)[0]]
        assert np.allclose(row, a + weight*(b-a), atol=1e-6)
        assert y[np.flatnonzero(ids == left)[0]] == y[np.flatnonzero(ids == right)[0]]
    for kind in ("classification", "regression"):
        for name in MODELS:
            encoder = dict(preprocess=state, state=neural_model("tabnet", 7, 7).state_dict())
            model = fit_model(name, x[fit], y[fit], ids[fit], kind, "none", 2, encoder)
            prediction = predict(model, x[score])
            metrics(y[score], prediction, kind)
            with tempfile.TemporaryDirectory() as folder:
                path = Path(folder) / "model.joblib"
                joblib.dump(model, path)
                assert np.array_equal(prediction, predict(joblib.load(path), x[score]))
    assert permutation_p(np.array([0, 0, 0, 1, 1, 1]), np.arange(6)) == .05
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder) / "sealed.json"
        write_json(path, {})
        try:
            write_json(path, {})
        except FileExistsError:
            pass
        else:
            raise AssertionError("Seal was overwritten")
    print("Passed: deterministic splits, train-only preprocessing, SMOTE lineage, all model heads, checkpoint round trips, exact permutation, overwrite refusal.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=("fetch", "prepare", "prepare-aalto", "train", "evaluate", "check"), required=True)
    parser.add_argument("--output", type=Path, default=Path(__file__).parent / "runs")
    parser.add_argument("--epochs", type=int, default=100)
    args = parser.parse_args()
    if args.epochs < 1:
        parser.error("--epochs must be positive")
    torch.set_num_threads(1)
    with threadpool_limits(limits=1):
        if args.phase == "fetch":
            fetch_tappy()
        elif args.phase == "prepare":
            prepare(args.output)
        elif args.phase == "prepare-aalto":
            prepare_aalto(args.output)
        elif args.phase == "train":
            train(args.output, args.epochs)
        elif args.phase == "evaluate":
            evaluate(args.output)
        else:
            check()


if __name__ == "__main__":
    main()
