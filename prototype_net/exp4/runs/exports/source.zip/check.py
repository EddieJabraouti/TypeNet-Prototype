import copy
import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import numpy as np
import torch

from prototype_net.exp4.model import TypingClassifier, sha256, write_json
from prototype_net.exp4.baseline import BaselineMonitor

torch.set_num_threads(1)
folder = Path('prototype_net/exp4/runs/exports')
source = Path('prototype_net/exp4/runs/baseline_monitor')
payload = json.loads((source/'example-input.json').read_text())
engine = TypingClassifier()
original = engine.classify(payload)
native_load = torch.load
def memory_only(source, *args, **kwargs):
    if isinstance(source, (str,Path)):
        raise AssertionError('Export attempted to read external encoder weights')
    return native_load(source,*args,**kwargs)
with patch.object(Path,'read_text',side_effect=AssertionError('External manifest access')), patch('torch.load',side_effect=memory_only):
    restored = TypingClassifier.load(folder/'classifier.joblib')
    baseline = BaselineMonitor.load(folder/'baseline.joblib',payload['participant_id'],payload['context_id'])
    assert restored.classify(payload) == original
    assert baseline.engine.classify(payload) == original
assert baseline.state['baseline_batches'] == 1
assert baseline.state['history'] == [] and len(baseline.baseline) == 0

expected = json.loads((source/'results.json').read_text())['example']
monitor = BaselineMonitor(restored,payload['participant_id'],payload['context_id'],3)
monitor.restore(source/'example-state.npz')
assert monitor.observe(payload) == expected
assert monitor.engine.classify(payload)['pd_score'] == expected['pd_score']
with tempfile.TemporaryDirectory() as t:
    artifact = Path(t)/'baseline.joblib'
    monitor.export(artifact)
    new = BaselineMonitor.load(artifact,payload['participant_id'],payload['context_id'])
    assert len(new.baseline) == 0 and new.state['history'] == []
    assert new.state['baseline_batches'] == 3
    new.restore(source/'example-state.npz')
    assert new.observe(payload) == expected
    for fn in (lambda: monitor.export(artifact),lambda: engine.export(artifact)):
        try:
            fn()
            raise AssertionError('Export overwrote an existing file')
        except FileExistsError:
            pass
for fn in (lambda: TypingClassifier.load(folder/'baseline.joblib'),
           lambda: BaselineMonitor.load(folder/'classifier.joblib','p','k')):
    try:
        fn()
        raise AssertionError('Wrong variant accepted')
    except ValueError:
        pass

data = np.load('prototype_net/exp4/runs/baseline_embeddings/300/dataset.npz')
saved = np.load(source/'scores.npz')
probabilities = restored.probabilities(data['x'])
rebuilt = np.stack([probabilities[:,(data['owner']==uid)&(data['batch']==b)].mean(1)
                    for uid,b in zip(saved['owner'],saved['batch'])])
np.testing.assert_array_equal(rebuilt,saved['scores'])
np.testing.assert_array_equal(probabilities,baseline.engine.probabilities(data['x']))

train = data['split']=='train'
before = engine.probabilities(data['x'][:12])
weights = {k:v.clone() for k,v in engine.encoder.state_dict().items()}
tuned = engine.fit(data['x'][train],data['y'][train],data['owner'][train],
                   parameters=dict(n_estimators=3,max_depth=1,learning_rate=.1))
assert len(tuned.models)==1 and len(engine.models)==25
assert tuned.models[0]['estimator'].get_params()['n_estimators']==3
assert tuned.models[0]['estimator'].get_params()['max_depth']==1
np.testing.assert_allclose(tuned.models[0]['preprocess']['scaler'].mean_,data['x'][train].mean(0,dtype=float),atol=1e-12)
np.testing.assert_array_equal(before,engine.probabilities(data['x'][:12]))
assert all(torch.equal(v,weights[k]) for k,v in engine.encoder.state_dict().items())
assert tuned.fingerprint != engine.fingerprint
assert tuned.classify(payload)['model_score_sd']==0
with tempfile.TemporaryDirectory() as t:
    tuned.export(Path(t)/'classifier.joblib')
    assert TypingClassifier.load(Path(t)/'classifier.joblib').classify(payload)==tuned.classify(payload)
    tuned_monitor = BaselineMonitor(tuned,payload['participant_id'],payload['context_id'],3)
    try:
        tuned_monitor.restore(source/'example-state.npz')
        raise AssertionError('New model accepted baseline scores from old models')
    except ValueError:
        pass
try:
    engine.fit(data['x'][train],data['y'][train],data['owner'][train],parameters={'max_dept':2})
    raise AssertionError('Misspelled hyperparameter accepted')
except ValueError:
    pass
write_json(folder/'verification.json',dict(passed=True,models=25,batches=len(rebuilt),
    predictions_exactly_preserved=True,old_baseline_state_compatible=True,
    both_exports_load_without_training_runs_or_encoder_files=True,
    model_exports_contain_no_personal_baseline=True,
    parameterized_training_smoke_test_only=True,current_models_unchanged=True,
    artifacts={name:sha256(folder/name) for name in ('classifier.joblib','baseline.joblib')}))
print('Passed: both independent exports, all 1432 batch scores exactly preserved, old state compatibility, stateless classification, separate training parameters, frozen original models.')
