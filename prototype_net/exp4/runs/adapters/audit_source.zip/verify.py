import ast,json,math,zipfile
from pathlib import Path
from collections import Counter
import joblib,numpy as np,torch
from sklearn.metrics import accuracy_score,roc_auc_score
from threadpoolctl import threadpool_limits
from prototype_net.exp4.model import ROOT,typenet_verify,sha256,write_json,predict_adapters,adapter_features,ResidualTabNet,preprocess

torch.set_num_threads(1);threadpool_limits(limits=1)
out=ROOT/'prototype_net/exp4/runs/adapters';reg=typenet_verify(out)
parent=ROOT/reg['data_run'];old=json.loads((parent/'registration.json').read_text())
assert sha256(parent/'registration.json')==reg['data_registration_sha256']
assert sha256(parent/'source.zip')==reg['data_source_sha256']
assert sha256(parent/'dataset.npz')==sha256(out/'dataset.npz')==reg['dataset_sha256']
for key in ('counts','splits','folds','modes','epochs','seed','threshold','encoder_sha256'):assert reg[key]==old[key]
assert reg['families']==['xgboost','random_forest','tabnet']
assert reg['fits']==dict(classifiers=225,additional_adapter_training=100)
with zipfile.ZipFile(parent/'source.zip') as z:before=ast.parse(z.read('prototype_net/exp4/model.py'))
after=ast.parse((ROOT/'prototype_net/exp4/model.py').read_text())
def defs(t):return {n.name:ast.dump(n) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=defs(before),defs(after);assert all(b[k]==v for k,v in a.items() if k!='main')
fold_node=next(n for n in after.body if isinstance(n,ast.FunctionDef) and n.name=='adapter_fold')
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and (n.func.attr=='load_state_dict' or (n.func.attr=='load' and isinstance(n.func.value,ast.Name) and n.func.value.id in ('joblib','torch'))) for n in ast.walk(fold_node))
with np.load(out/'dataset.npz') as z:d={k:z[k] for k in z.files}
assert d['x'].shape==(6726,128) and d['baseline'].shape==(6726,6,128)
assert np.isfinite(d['x']).all() and np.isfinite(d['baseline']).all()
source=ROOT/reg['source_dataset'];assert sha256(source)==reg['source_dataset_sha256']
with np.load(source) as z:s={k:z[k] for k in z.files}
for key in ('x','y','owner','split','batch','lineage'):assert np.array_equal(d[key],s[key][s['batch']>0])
for uid in np.unique(d['owner']):
 reference=s['x'][(s['owner']==uid)&(s['batch']==0)];mask=d['owner']==uid
 assert np.array_equal(d['baseline'][mask],np.broadcast_to(reference,d['baseline'][mask].shape))
assert len(np.unique(s['lineage']))==s['lineage'].size
assert [len(reg['splits'][r]) for r in ('train','validation','test')]==[218,31,62]
assert len(set(sum(reg['splits'].values(),[])))==311
for repeat in range(1,6):
 counter=Counter()
 for fold in [f for f in reg['folds'] if f['repeat']==repeat]:
  fit,score=set(fold['fit']),set(fold['score']);assert not fit&score and fit|score==set(reg['splits']['train'])
  counter.update(fold['score'])
 assert set(counter)==set(reg['splits']['train']) and set(counter.values())=={1}
print('Matched data, full baseline matrices, folds, old functions and checkpoint-free training path verified.',flush=True)
if not (out/'results.json').exists():raise SystemExit(0)
freeze=json.loads((out/'freeze.json').read_text());results=json.loads((out/'results.json').read_text())
assert len(freeze['models'])==25 and freeze['registration_sha256']==sha256(out/'registration.json')
assert results['freeze_sha256']==sha256(out/'freeze.json') and results['predictions_sha256']==sha256(out/'predictions.npz')
with np.load(out/'predictions.npz') as z:pred={k:z[k] for k in z.files}
control_root=ROOT/'prototype_net/exp4/runs/baseline_embeddings'
with np.load(control_root/'300/predictions.npz') as z:controls={k:z[k] for k in z.files}
assert np.array_equal(pred['ids'],controls['ids']) and np.array_equal(pred['y'],controls['y'])
controls_freeze=json.loads((control_root/'freeze.json').read_text())
checks=0

def check_state(model,x,people,epochs=False):
 global checks
 state=model['preprocess'];x=x.astype(float);scaler=state['scaler']
 assert model['fit_rows']==len(x) and model['real_people']==people and not model['parents']
 assert scaler.n_samples_seen_==len(x) and scaler.n_features_in_==x.shape[1]
 np.testing.assert_allclose(state['medians'],np.median(x,axis=0))
 np.testing.assert_allclose(scaler.mean_,x.mean(0),rtol=1e-6,atol=1e-9)
 np.testing.assert_allclose(scaler.var_,x.var(0),rtol=1e-6,atol=1e-9)
 if epochs:assert model['epochs']==100 and model['optimizer_updates']==100*math.ceil(len(x)/512)
 checks+=1

for rec in freeze['models']:
 path=out/f"fold{rec['index']:02d}.joblib";assert sha256(path)==rec['sha256']
 bundle=joblib.load(path);assert bundle['registration_sha256']==freeze['registration_sha256']
 assert bundle['fold']==reg['folds'][rec['index']-1]
 assert set(bundle['models'])=={f'{family}_{mode}' for family in reg['families'] for mode in reg['modes']}
 fit=np.isin(d['owner'],bundle['fold']['fit']);x=d['x'][fit];base=d['baseline'][fit];people=len(bundle['fold']['fit'])
 oldpath=control_root/'300'/path.name
 assert sha256(oldpath)==next(r['sha256'] for r in controls_freeze['models'] if r['size']=='300' and r['index']==rec['index'])
 oldbundle=joblib.load(oldpath)
 for name,model in bundle['models'].items():
  family,mode=name.rsplit('_',1)
  if 'adapter' in model:
   assert model['adapter_origin']=='fresh training in this family/mode/fold'
   adapter=model['adapter'];check_state(adapter,x,people,True)
   state={k:v.clone() for k,v in adapter['state'].items()}
   features=adapter_features(adapter,x,base)
   assert features.shape[1]==(128 if mode=='residual' else 256)
   assert all(torch.equal(v,adapter['state'][k]) for k,v in state.items())
   check_state(model['classifier'],features,people)
   assert model['classifier']['estimator'].n_features_in_==features.shape[1]
   assert adapter['parameter_changes']['query.weight']>0 and adapter['parameter_changes']['key.weight']>0
  else:
   check_state(model,x,people,family=='tabnet')
   if mode=='population':
    previous=oldbundle['models'][f'{family}_population']
    if family=='tabnet':assert all(torch.equal(v,previous['state'][k]) for k,v in model['state'].items())
    else:
     p,q=model['estimator'].get_params(),previous['estimator'].get_params()
     for k in p:assert p[k]==q[k] or (isinstance(p[k],float) and np.isnan(p[k]) and np.isnan(q[k]))
   else:
    net=ResidualTabNet(mode);net.load_state_dict(model['state']);net.eval()
    tx,_=preprocess(x[:64],model['preprocess']);tb,_=preprocess(base[:64].reshape(-1,128),model['preprocess'])
    tx,tb=torch.from_numpy(tx),torch.from_numpy(tb.reshape(-1,6,128))
    with torch.inference_mode():torch.testing.assert_close(net(tx,tb),net(tx,tb.flip(1)),rtol=1e-4,atol=1e-5)
    assert model['parameter_changes']['query.weight']>0 and model['parameter_changes']['key.weight']>0
    if mode=='residual':assert net.gate.norm().item()>0
  probability=predict_adapters(model,d['x'],d['baseline'])
  grouped=np.array([probability[d['owner']==uid].mean() for uid in pred['ids']])
  np.testing.assert_allclose(grouped,pred[name][rec['index']-1],rtol=1e-7,atol=1e-8)
  if mode=='population':np.testing.assert_allclose(grouped,controls[name][rec['index']-1],rtol=1e-7,atol=1e-8)
 for mode in ('residual','late'):
  left=bundle['models']['xgboost_'+mode]['adapter'];right=bundle['models']['random_forest_'+mode]['adapter']
  assert left is not right and left['state']['query.weight'].data_ptr()!=right['state']['query.weight'].data_ptr()
 print('Verified fold',rec['index'],'nine classifiers, four independent tree adapters and predictions',flush=True)
assert checks==325
for a in results['aggregates']:
 mask=pred['split']==a['role'];y=pred['y'][mask];p=pred[a['candidate']][:,mask]
 assert p.shape==(25,a['people'])
 for key,values in [('accuracy',[accuracy_score(y,row>=.5) for row in p]),('auroc',[roc_auc_score(y,row) for row in p])]:
  assert np.isclose(np.mean(values),a[key]['mean']) and np.isclose(np.std(values,ddof=1),a[key]['sd'])
 assert np.isclose(accuracy_score(y,p.mean(0)>=.5),a['ensemble']['accuracy'])
 assert np.isclose(roc_auc_score(y,p.mean(0)),a['ensemble']['auroc'])
write_json(out/'verification.json',dict(passed=True,classifier_fits=225,fresh_tree_adapter_fits=100,preprocessing_states=325,keys=300,checks=[
 'same original real data, earlier baseline matrices and participant-disjoint repeated folds',
 'all prior functions unchanged; no checkpoint reads in the classifier training worker',
 'mechanism test proves four fresh independent adapter training calls per fold with checkpoint loading blocked',
 'no shared adapter objects between tree families; all fit preprocessing states are training-fold-only',
 'all fresh population controls reproduce previous saved predictions',
 'TabNet attention/correction/head jointly trained with original penalty; all neural fits use 100 epochs',
 'tree classifiers fit independently after their own adapters are trained and frozen',
 'all 225 classifier predictions reproduced and all checkpoint/encoder/data hashes verified',
 'all accuracy/AUROC/sample SD and ensemble metrics independently reproduced'],audit_sha256=sha256(__file__)))
with zipfile.ZipFile(out/'audit_source.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 z.write(__file__,'verify.py');z.write('/tmp/exp4_remaining_check.py','check.py')
print('Full three-family adapter verification passed.',flush=True)
