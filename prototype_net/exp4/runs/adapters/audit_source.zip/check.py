import ast,json,tempfile,zipfile
from pathlib import Path
import joblib,numpy as np,torch
from threadpoolctl import threadpool_limits
from prototype_net.exp4 import model as m

torch.set_num_threads(1);threadpool_limits(limits=1)
with zipfile.ZipFile(m.ROOT/'prototype_net/exp4/runs/residual/source.zip') as z:old=ast.parse(z.read('prototype_net/exp4/model.py'))
new=ast.parse(Path(m.__file__).read_text())
def defs(t):return {n.name:ast.dump(n) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=defs(old),defs(new);assert all(b[k]==v for k,v in a.items() if k!='main')
rng=np.random.default_rng(m.SEED)
x=rng.normal(size=(120,128)).astype('float32');base=rng.normal(size=(120,6,128)).astype('float32')
ids=np.repeat(np.array([f'p{i:02}' for i in range(30)]),4);y=np.repeat(np.tile([0,1],15),4)
tx,tb=torch.from_numpy(x),torch.from_numpy(base)
torch.manual_seed(m.SEED);control=m.neural_model('tabnet',128,2);control.initialize(tx);control.eval()
torch.manual_seed(m.SEED);res=m.ResidualTabNet('residual');res.initialize(tx,tb);res.eval()
assert all(torch.equal(v,res.head.state_dict()[k]) for k,v in control.state_dict().items())
assert torch.equal(control(tx)[0],res(tx,tb))
for mode in ('residual','late'):
 net=m.ResidualTabNet(mode)
 if mode=='residual':net.gate.data.fill_(.2)
 net.initialize(tx,tb);net.eval()
 torch.testing.assert_close(net(tx,tb),net(tx,tb.flip(1)),rtol=1e-5,atol=1e-6)
 net.train();output,penalty=net.head(net.representation(tx,tb))
 (torch.nn.functional.cross_entropy(output,torch.tensor(y))+.001*penalty).backward()
 assert net.query.weight.grad.norm()>0 and net.key.weight.grad.norm()>0
 assert net.correction[0].weight.grad.norm()>0
calls=[];original_fit=m.fit_residual;original_load=joblib.load
def fresh(*args,**kwargs):
 result=original_fit(*args,**kwargs);calls.append(result);return result
def no_checkpoints(*args,**kwargs):raise AssertionError('Training attempted to load a checkpoint')
m.fit_residual=fresh;joblib.load=no_checkpoints
try:
 with tempfile.TemporaryDirectory() as temp:
  out=Path(temp)
  people=np.unique(ids);fold=dict(fit=people[:24].tolist(),score=people[24:].tolist(),repeat=1,fold=1)
  reg=dict(folds=[fold],families=['xgboost','random_forest','tabnet'],modes=['population','residual','late'],epochs=3)
  (out/'registration.json').write_text(json.dumps(reg))
  np.savez_compressed(out/'dataset.npz',x=x,baseline=base,y=y,owner=ids,split=np.full(len(x),'train'))
  m.adapter_fold((out,0))
  assert len(calls)==4 and len({id(v) for v in calls})==4
  bundle=original_load(out/'fold01.joblib');assert len(bundle['models'])==9
  for mode in ('residual','late'):
   left=bundle['models']['xgboost_'+mode]['adapter'];right=bundle['models']['random_forest_'+mode]['adapter']
   assert left is not right and left['state']['query.weight'].data_ptr()!=right['state']['query.weight'].data_ptr()
  for name,model in bundle['models'].items():
   p=m.predict_adapters(model,x,base);assert np.isfinite(p).all() and ((p>=0)&(p<=1)).all()
   path=out/'roundtrip.joblib';joblib.dump(model,path)
   assert np.array_equal(p,m.predict_adapters(original_load(path),x,base))
finally:
 m.fit_residual=original_fit;joblib.load=original_load
print('Passed: prior functions unchanged, TabNet initial identity and attention gradients, all nine pipelines, four separate fresh tree-adapter training calls, no checkpoint loading during training, and checkpoint round trips.')
