import ast
import copy
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
import numpy as np
import torch
from scipy.spatial.distance import cdist, pdist
from sklearn.metrics.pairwise import rbf_kernel
from prototype_net.exp4.model import ROOT, PersonalMonitor, baseline_distance, sha256, write_json

torch.set_num_threads(1)
out = ROOT / 'prototype_net/exp4/runs/monitor'
run = out.parent / 'real'
report = json.loads((out/'results.json').read_text())
reg = json.loads((out/'registration.json').read_text())
training = json.loads((run/'registration.json').read_text())
payloads = [json.loads(line) for line in (out/'replay.jsonl').read_text().splitlines()]
assert len(payloads) == 2 and len({p['participant_id'] for p in payloads}) == 1
assert report['synthetic_rows'] == 0
uid = payloads[0]['participant_id']
assert uid not in training['splits']['train']
ids = [{(e['session_id'],e['event_id']) for e in p['events']} for p in payloads]
assert all(len(s)==2500 for s in ids) and not ids[0]&ids[1]
assert payloads[0]['timestamp_ms'] < payloads[1]['timestamp_ms']
assert all('diagnosis' not in p and 'label' not in p for p in payloads)
assert sha256(out/'matrices.npz') == report['matrices_sha256']
assert sha256(out/'replay.jsonl') == report['replay_sha256']
for name,digest in reg['source_hashes'].items():
    assert sha256(ROOT/name) == digest
with zipfile.ZipFile(run/'source.zip') as z:
    old = ast.parse(z.read('prototype_net/exp4/model.py'))
current = ast.parse((ROOT/'prototype_net/exp4/model.py').read_text())
def definitions(tree):
    return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=definitions(old),definitions(current)
assert all(b[n]==v for n,v in a.items() if n!='main')

monitor=PersonalMonitor(run,uid)
encoder_before={k:v.clone() for k,v in monitor.encoder.state_dict().items()}
short=copy.deepcopy(payloads[0]);short['events']=short['events'][:100]
state_before=copy.deepcopy(monitor.state)
assert monitor.observe(short)['status']=='insufficient_data'
assert monitor.baseline is None and monitor.state==state_before
first=monitor.observe(payloads[0]);baseline=monitor.baseline.copy()
assert baseline.shape==(50,135)
with tempfile.TemporaryDirectory() as folder:
    folder=Path(folder)
    state_path=folder/'state.npz'
    monitor.save(state_path)
    restored=PersonalMonitor(run,uid);restored.restore(state_path)
    assert np.array_equal(baseline,restored.baseline)
    short=copy.deepcopy(payloads[1]);short['events']=short['events'][:100]
    state_before=copy.deepcopy(restored.state)
    assert restored.observe(short)['status']=='insufficient_data'
    assert restored.state==state_before and np.array_equal(restored.baseline,baseline)
    second=restored.observe(payloads[1])
    assert np.array_equal(restored.baseline,baseline)
    assert np.isclose(first['pd_score'],report['results'][0]['pd_score'])
    assert np.isclose(second['pd_score'],report['results'][1]['pd_score'])
    direct=monitor.observe(payloads[1])
    assert direct==second
    with np.load(out/'matrices.npz') as matrices:
        prefix=uid.replace(':','_')
        assert np.array_equal(matrices[prefix+'_batch0_features'],baseline)
        assert np.array_equal(matrices[prefix+'_batch1_features'],restored.last_features)
        assert matrices[prefix+'_batch0_embeddings'].shape==(50,128)
        assert matrices[prefix+'_batch1_embeddings'].shape==(50,128)
    base,current=baseline[:,:128].astype(float),restored.last_features[:,:128].astype(float)
    distance=baseline_distance(base,current)
    gamma=1/np.median(pdist(base,'sqeuclidean'))
    reference=rbf_kernel(base,gamma=gamma).mean()+rbf_kernel(current,gamma=gamma).mean()-2*rbf_kernel(base,current,gamma=gamma).mean()
    assert np.isclose(distance['mmd2'],reference,atol=1e-12)
    assert np.isclose(distance['embedding_distance'],cdist(base,current).mean(),atol=1e-12)
    assert np.isclose(distance['baseline_within_distance'],pdist(base).mean(),atol=1e-12)
    assert np.isclose(baseline_distance(base,base)['mmd2'],0,atol=1e-12)
    assert np.isclose(baseline_distance(base,current[::-1])['mmd2'],distance['mmd2'])
    assert np.isclose(second['pd_score_change'],second['pd_score']-first['pd_score'])
    def rejected(payload):
        state=copy.deepcopy(restored.state)
        try:restored.observe(payload)
        except ValueError:pass
        else:raise AssertionError('Expected rejection')
        assert restored.state==state and np.array_equal(restored.baseline,baseline)
    rejected(payloads[1])
    bad=copy.deepcopy(payloads[1]);bad['batch_id']='overlap';bad['timestamp_ms']+=1;rejected(bad)
    bad=copy.deepcopy(payloads[1]);bad['participant_id']='wrong';rejected(bad)
    bad=copy.deepcopy(payloads[1]);bad['batch_id']='old';bad['timestamp_ms']=0;rejected(bad)
    bad=copy.deepcopy(payloads[1]);bad['batch_id']='malformed';bad['timestamp_ms']+=2;bad['events'][0]['keyup_ms']=0;rejected(bad)
    wrong=PersonalMonitor(run,'wrong')
    try:wrong.restore(state_path)
    except ValueError:pass
    else:raise AssertionError('State accepted wrong participant')
    numeric=copy.deepcopy(payloads[0])
    for e in numeric['events']:
        code=e.pop('keycode');e['key']='.' if code>255 else chr(int(code))
    converted,_,count=monitor.encode(numeric['events'])
    assert count==50 and np.array_equal(converted,baseline)
    for i,payload in enumerate(payloads):
        path=folder/f'input{i}.json';path.write_text(json.dumps(payload))
        output=folder/f'output{i}.json'
        subprocess.run([sys.executable,'-m','prototype_net.exp4.model','--phase','monitor','--baseline',str(run),
                        '--input',str(path),'--state',str(folder/'cli.npz'),'--output',str(output)],check=True,cwd=ROOT,capture_output=True)
        value=json.loads(output.read_text())
        assert value==[first,second][i]
    cli=PersonalMonitor(run,uid);cli.restore(folder/'cli.npz')
    assert np.array_equal(cli.baseline,baseline) and len(cli.state['batches'])==2
    # Repeated state updates tested with disjoint real excerpts; primary replay stays 50 windows.
    stream=PersonalMonitor(run,uid,batch_size=10)
    for i in range(4):
        item=copy.deepcopy(payloads[0]);item['batch_id']=f'stream{i}';item['timestamp_ms']+=i
        item['events']=item['events'][i*500:(i+1)*500]
        value=stream.observe(item)
        assert value['status']==('baseline_ready' if i==0 else 'scored')
        if i==0:stream_baseline=stream.baseline.copy()
        assert np.array_equal(stream.baseline,stream_baseline)
        stream.save(folder/'stream.npz')
        stream=PersonalMonitor(run,uid,batch_size=10);stream.restore(folder/'stream.npz')
    assert len(stream.state['batches'])==4 and len(stream.state['event_ids'])==2000
assert all(torch.equal(encoder_before[k],v) for k,v in monitor.encoder.state_dict().items())
assert sha256(ROOT/training['encoder'])==reg['encoder_sha256']
assert sha256(run/'freeze.json')==reg['checkpoint_freeze_sha256']
write_json(out/'verification.json',dict(passed=True,primary_batch_shape=[50,128],primary_participants=1,
    primary_baseline_and_followup_disjoint_keys=5000,primary_participant_excluded_from_classifier_training=True,
    checks=['prior training and inference functions unchanged','frozen checkpoint hashes verified',
            'fresh embeddings match saved matrices','classifier scores reproduce after restart',
            'CLI baseline and follow-up reproduce class API','fixed baseline unchanged across updates',
            'MMD and distances match independent sklearn/scipy computations','matrix row order does not change MMD',
            'insufficient batches do not change state','duplicate, overlapping, malformed, out-of-order and wrong-user inputs rejected',
            'printable-key and normalized-keycode inputs agree','four persisted stream updates using disjoint real 10-window test batches'],
    audit_sha256=sha256(__file__)))
with zipfile.ZipFile(out/'audit_source.zip','x',compression=zipfile.ZIP_DEFLATED) as z:z.write(__file__,'verify.py')
print('All monitor and CLI verification checks passed.')
