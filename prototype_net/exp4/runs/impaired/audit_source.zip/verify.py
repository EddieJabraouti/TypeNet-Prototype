import ast,json,zipfile
from pathlib import Path
import numpy as np
import torch
from prototype_net.exp4.model import ROOT, PersonalMonitor, baseline_distance, sha256, write_json

torch.set_num_threads(1)
out=ROOT/'prototype_net/exp4/runs/impaired';run=out.parent/'real'
r=json.loads((out/'results.json').read_text());g=json.loads((out/'registration.json').read_text())
p=[json.loads(s) for s in (out/'replay.jsonl').read_text().splitlines()]
assert len(p)==len(r['results'])==10 and r['synthetic_keystrokes']==0
for file,key in [('replay.jsonl','replay_sha256'),('matrices.npz','matrices_sha256')]:assert sha256(out/file)==r[key]
with zipfile.ZipFile(out.parent/'monitor/source.zip') as z:old=ast.parse(z.read('prototype_net/exp4/model.py'))
new=ast.parse((ROOT/'prototype_net/exp4/model.py').read_text())
def defs(tree):return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=defs(old),defs(new);assert all(b[k]==v for k,v in a.items() if k!='main')
monitor=PersonalMonitor(run,'demo:control_to_pd')
seen=set()
with np.load(out/'matrices.npz') as m:
 baseline=m['batch00_features']
 for i,(payload,result) in enumerate(zip(p,r['results'])):
  ids={(e['session_id'],e['event_id']) for e in payload['events']}
  assert len(ids)==2500 and not ids&seen;seen.update(ids)
  features,_,count=monitor.encode(payload['events'])
  assert count==50 and np.array_equal(features,m[f'batch{i:02d}_features'])
  assert np.array_equal(features[:,:128],m[f'batch{i:02d}_embeddings'])
  score=float(monitor.probabilities(features).mean())
  assert score==result['pd_score'] and int(score>=.5)==result['predicted_class']
  if i:
   assert result['baseline_pd_score']==r['results'][0]['pd_score']
   assert np.isclose(result['pd_score_change'],score-r['results'][0]['pd_score'])
   for k,v in baseline_distance(baseline[:,:128],features[:,:128]).items():
    if isinstance(v,float):assert np.isclose(v,result[k])
 monitor.restore(out/'state.npz')
 assert np.array_equal(monitor.baseline,baseline)
 assert len(monitor.state['batches'])==10 and len(monitor.state['event_ids'])==25000
with np.load(out.parent/'typenet/dataset.npz') as d:
 eligible=[]
 for uid in np.unique(d['owner']):
  first=np.flatnonzero(d['owner']==uid)[0]
  if d['y'][first]==1 and np.sum((d['owner']==uid)&~d['synthetic']&(d['lengths']==50))>=50:eligible.append(uid)
 assert set(eligible)=={v['source_participant'] for v in r['results'] if v['scenario_role']=='pd_followup'}
 assert len(eligible)==8
 for result in r['results']:
  assert result['source_label']==int(d['y'][np.flatnonzero(d['owner']==result['source_participant'])[0]])
previous=json.loads((out.parent/'monitor/results.json').read_text())
assert all(r['results'][i]['pd_score']==previous['results'][i]['pd_score'] for i in (0,1))
assert r['pd_classified_pd']==sum(v['predicted_class'] for v in r['results'][2:])==6
assert r['pd_classified_control']==2
for name,digest in g['source_hashes'].items():assert sha256(ROOT/name)==digest
assert sha256(run/'freeze.json')==g['checkpoint_freeze_sha256']
write_json(out/'verification.json',dict(passed=True,checks=['all eight eligible PD participants included',
 '25000 unique real events across ten disjoint batches','all matrices freshly reproduce from replay events',
 'all scores reproduce from frozen classifiers','baseline unchanged after nine follow-ups',
 'source labels agree with clinical data','control results match prior simulation','monitor implementation unchanged'],
 audit_sha256=sha256(__file__)))
with zipfile.ZipFile(out/'audit_source.zip','x',compression=zipfile.ZIP_DEFLATED) as z:z.write(__file__,'verify.py')
print('Impaired replay verification passed: 6 of 8 PD batches classified PD, 2 classified control.')
