import ast
import json
import zipfile
from collections import Counter
from pathlib import Path
import joblib
import numpy as np
import torch
from sklearn.metrics import accuracy_score, roc_auc_score
from threadpoolctl import threadpool_limits
from prototype_net.exp4.model import ROOT, MODELS, ROLES, sha256, typenet_verify, write_json, predict

torch.set_num_threads(1)
threadpool_limits(limits=1)
out = ROOT / 'prototype_net/exp4/runs/embeddings'
baseline = out.parent / 'real'
reg = typenet_verify(out)
original = json.loads((baseline / 'registration.json').read_text())
assert sha256(baseline / 'registration.json') == reg['baseline_registration_sha256']
assert sha256(baseline / 'source.zip') == reg['baseline_source_sha256']
assert sha256(baseline / 'dataset.npz') == original['dataset_sha256']
for key in ('seed', 'repeats', 'folds', 'families', 'augmentation', 'epochs', 'threshold', 'splits', 'counts', 'encoder', 'encoder_sha256'):
    assert reg[key] == original[key], key
assert reg['features'] == 128 and reg['epochs'] == 100 and reg['augmentation'] == [0]
with np.load(out / 'dataset.npz', allow_pickle=False) as cache:
    data = {key: cache[key] for key in cache.files}
with np.load(baseline / 'dataset.npz', allow_pickle=False) as cache:
    assert set(cache.files) == set(data)
    for key, value in data.items():
        assert np.array_equal(value, cache[key][:, :128] if key == 'x' else cache[key]), key
assert data['x'].shape == (12916, 128) and np.isfinite(data['x']).all()
assert not data['synthetic'].any()
ids = np.unique(data['owner'])
first = np.array([np.flatnonzero(data['owner'] == uid)[0] for uid in ids])
labels = data['y'][first]
assert len(ids) == 317
assert [len(reg['splits'][role]) for role in ROLES] == [221, 32, 64]
for role in ROLES:
    assert set(data['owner'][data['split'] == role]) == set(reg['splits'][role])
assert len(set(sum(reg['splits'].values(), []))) == 317
for repeat in range(1, 6):
    counter = Counter()
    for fold in [f for f in reg['folds'] if f['repeat'] == repeat]:
        fit, score = set(fold['fit']), set(fold['score'])
        assert not fit & score and fit | score == set(reg['splits']['train'])
        counter.update(fold['score'])
    assert set(counter) == set(reg['splits']['train']) and set(counter.values()) == {1}
with zipfile.ZipFile(baseline / 'source.zip') as archive:
    old = ast.parse(archive.read('prototype_net/exp4/model.py'))
new = ast.parse((ROOT / 'prototype_net/exp4/model.py').read_text())
def definitions(tree):
    return {n.name: ast.dump(n, include_attributes=False) for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
a, b = definitions(old), definitions(new)
assert all(b[name] == value for name, value in a.items() if name != 'main')
print('Verified: exactly the original 128 embedding columns, identical observations/splits/folds, no synthetic data, unchanged original functions.', flush=True)
if not (out / 'results.json').exists():
    raise SystemExit(0)
freeze = json.loads((out / 'freeze.json').read_text())
old_freeze = json.loads((baseline / 'freeze.json').read_text())
assert freeze['registration_sha256'] == sha256(out / 'registration.json')
assert len(freeze['models']) == 25
with np.load(out / 'predictions.npz', allow_pickle=False) as cache:
    predictions = {key: cache[key] for key in cache.files}
for record in freeze['models']:
    index = record['index']
    path = out / f'fold{index:02d}.joblib'
    assert sha256(path) == record['sha256']
    bundle = joblib.load(path)
    assert bundle['registration_sha256'] == freeze['registration_sha256']
    assert bundle['fold'] == reg['folds'][index-1]
    old_path = baseline / path.name
    assert sha256(old_path) == next(r['sha256'] for r in old_freeze['models'] if r['index'] == index)
    previous = joblib.load(old_path)
    assert previous['fold'] == bundle['fold']
    mask = np.isin(data['owner'], bundle['fold']['fit'])
    x = data['x'][mask].astype(np.float64)
    assert set(bundle['models']) == {f'{family}_0' for family in MODELS}
    for family in MODELS:
        model = bundle['models'][f'{family}_0']
        old_model = previous['models'][f'{family}_0']
        state = model['preprocess']
        assert model['real_rows'] == int(mask.sum()) == model['fit_rows']
        assert model['real_people'] == len(bundle['fold']['fit'])
        assert model['synthetic_rows'] == 0 and not model['parents'] and model['encoder'] is None
        assert len(state['medians']) == state['scaler'].n_features_in_ == 128
        assert np.allclose(state['medians'], np.median(x, axis=0))
        assert np.allclose(state['scaler'].mean_, x.mean(0), rtol=1e-6, atol=1e-10)
        assert np.allclose(state['scaler'].var_, x.var(0), rtol=1e-6, atol=1e-10)
        assert state['scaler'].n_samples_seen_ == len(x)
        if family in ('node', 'tabnet'):
            for key in ('epochs', 'optimizer_updates', 'batch_size'):
                assert model[key] == old_model[key]
            assert model['features'] == 128
        else:
            assert model['estimator'].n_features_in_ == 128
            p, q = model['estimator'].get_params(), old_model['estimator'].get_params()
            for key in p:
                assert p[key] == q[key] or (isinstance(p[key], float) and np.isnan(p[key]) and np.isnan(q[key])), key
        probability = predict(model, data['x'])
        grouped = np.array([probability[data['owner'] == uid].mean() for uid in ids])
        np.testing.assert_allclose(grouped, predictions[family][index-1], rtol=1e-7, atol=1e-8)
    print(f'Verified fold {index}/25: all four checkpoints, preprocessing, configurations and predictions.', flush=True)
results = json.loads((out / 'results.json').read_text())
assert results['freeze_sha256'] == sha256(out / 'freeze.json')
assert results['predictions_sha256'] == sha256(out / 'predictions.npz')
assert np.array_equal(predictions['ids'], ids) and np.array_equal(predictions['y'], labels)
for aggregate in results['aggregates']:
    mask = predictions['split'] == aggregate['role']
    if aggregate['cohort'] != 'all':
        mask &= predictions['cohort'] == aggregate['cohort']
    y = predictions['y'][mask]
    p = predictions[aggregate['family']][:, mask]
    assert p.shape == (25, aggregate['people'])
    for key, scores in [('accuracy', [accuracy_score(y, row >= .5) for row in p]),
                        ('auroc', [roc_auc_score(y, row) for row in p])]:
        assert np.isclose(np.mean(scores), aggregate[key]['mean'])
        assert np.isclose(np.std(scores, ddof=1), aggregate[key]['sd'])
    assert np.isclose(accuracy_score(y, p.mean(0) >= .5), aggregate['ensemble']['accuracy'])
    assert np.isclose(roc_auc_score(y, p.mean(0)), aggregate['ensemble']['auroc'])
write_json(out / 'verification.json', dict(passed=True, fits=100, features=128, synthetic_rows=0,
    checks=['exact original embedding columns; all observations and metadata retained',
            'identical participant splits and five complete participant-disjoint CV repeats',
            'original model definitions, training and evaluation functions unchanged',
            '100 fold-only scalers and imputers; 128 inputs on every checkpoint',
            'same tree hyperparameters, neural epochs, optimizer updates and batch sizes as original',
            'all saved participant predictions reproduced from all 100 checkpoints',
            'all model, input and encoder hashes unchanged',
            'all participant accuracy, AUROC, sample SD and ensemble metrics reproduce'],
    audit_sha256=sha256(__file__)))
with zipfile.ZipFile(out / 'audit_source.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    archive.write(__file__, 'verify.py')
print('Full verification passed.', flush=True)
