import ast,json,zipfile
from collections import Counter
from pathlib import Path
import joblib
import torch
from threadpoolctl import threadpool_limits
import numpy as np
from sklearn.metrics import accuracy_score,roc_auc_score
from prototype_net.exp4.model import ROOT,personal_verify,sha256,write_json,predict
torch.set_num_threads(1)
threadpool_limits(limits=1)
out=ROOT/'prototype_net/exp4/runs/baseline_embeddings';reg=personal_verify(out)
source=ROOT/reg['comparison_run']
comparison=json.loads((source/'registration.json').read_text())
assert sha256(source/'registration.json')==reg['comparison_registration_sha256']
assert sha256(source/'source.zip')==reg['comparison_source_sha256']
assert reg['families']==['xgboost','random_forest','tabnet','node']
for key in ('seed','repeats','epochs','arms','threshold','encoder','encoder_sha256','events_sha256'):
 assert reg[key]==comparison[key]
for name,digest in reg['input_hashes'].items():assert sha256(ROOT/name)==digest
original=json.loads((Path(reg['baseline_run'])/'registration.json').read_text())
with np.load(out/'events.npz') as a:events=a['events']
assert sha256(out/'events.npz')==reg['events_sha256']
with zipfile.ZipFile(source/'source.zip') as z:old=ast.parse(z.read('prototype_net/exp4/model.py'))
new=ast.parse((ROOT/'prototype_net/exp4/model.py').read_text())
def defs(tree):return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=defs(old),defs(new);assert all(b[k]==v for k,v in a.items() if k!='main')
for size,s in reg['scenarios'].items():
 with np.load(out/size/'dataset.npz') as a:d={k:a[k] for k in a.files}
 for key in ('splits','folds','counts','keys_per_batch','windows_per_batch','selection'):
  assert s[key]==comparison['scenarios'][size][key]
 assert sha256(source/size/'dataset.npz')==s['source_dataset_sha256']
 with np.load(source/size/'dataset.npz') as old:
  for key,value in d.items():
   if key!='personal':assert np.array_equal(value,old[key][:,:128] if key=='x' else old[key]),key
 assert d['x'].shape[1]==128 and d['personal'].shape[1]==128*(s['windows_per_batch']+1)
 assert np.all(d['personal'][d['batch']==0]==0)
 assert np.isfinite(d['personal']).all() and np.isfinite(d['x']).all()
 assert len(np.unique(d['lineage']))==d['lineage'].size
 assert np.all(events[d['lineage'],0]==d['owner'][:,None])
 assert set(d['owner'])==set(sum(s['splits'].values(),[]))
 for role,ids in s['splits'].items():
  assert set(ids)<=set(original['splits'][role])
  assert set(d['owner'][d['split']==role])==set(ids)
 for uid in np.unique(d['owner']):
  base=(d['owner']==uid)&(d['batch']==0);post=(d['owner']==uid)&(d['batch']>0)
  assert base.sum()==s['windows_per_batch']
  reference=d['x'][base]
  for batch in np.unique(d['batch'][post]):
   mask=(d['owner']==uid)&(d['batch']==batch)
   assert mask.sum()==s['windows_per_batch']
   f=d['personal'][mask]
   assert np.array_equal(f[:,:128],d['x'][mask])
   assert np.array_equal(f[:,128:],np.broadcast_to(reference.reshape(-1),(int(mask.sum()),reference.size)))
   # The final sequence of every batch has no timing input from future keys.
   assert np.array_equal(d['raw'][np.flatnonzero(mask)[-1],-1,1:4],np.zeros(3))
  base_ids=d['lineage'][base].ravel();post_ids=d['lineage'][post].ravel()
  assert not set(base_ids)&set(post_ids)
  base_sessions=set(events[base_ids,1]);post_sessions=set(events[post_ids,1])
  def order(session):return int(session.split('.')[0]) if uid.startswith('nq:') else int(session.rsplit(':',1)[1])
  assert max(map(order,base_sessions))<=min(map(order,post_sessions))
  if size=='400':assert not base_sessions&post_sessions and max(map(order,base_sessions))<min(map(order,post_sessions))
  for session in base_sessions&post_sessions:
   bp=events[base_ids[events[base_ids,1]==session],3].astype(float)
   pp=events[post_ids[events[post_ids,1]==session],3].astype(float)
   assert bp.max()<=pp.min()
 for repeat in range(1,6):
  c=Counter()
  for f in [f for f in s['folds'] if f['repeat']==repeat]:
   fit,score=set(f['fit']),set(f['score']);assert not fit&score and fit|score==set(s['splits']['train'])
   c.update(f['score'])
  assert set(c)==set(s['splits']['train']) and set(c.values())=={1}
 print(size,'data/chronology/folds verified',flush=True)
if not (out/'results.json').exists():raise SystemExit(0)
freeze=json.loads((out/'freeze.json').read_text());results=json.loads((out/'results.json').read_text())
assert len(freeze['models'])==50 and results['freeze_sha256']==sha256(out/'freeze.json')
for size,s in reg['scenarios'].items():
 with np.load(out/size/'dataset.npz') as a:d={k:a[k] for k in ('x','personal','owner','split','batch','y')}
 for record in [r for r in freeze['models'] if r['size']==size]:
  path=out/size/f"fold{record['index']:02d}.joblib";assert sha256(path)==record['sha256']
  bundle=joblib.load(path)
  assert bundle['fold']==s['folds'][record['index']-1]
  assert bundle['registration_sha256']==freeze['registration_sha256']
  assert set(bundle['models'])=={f'{family}_{arm}' for family in reg['families'] for arm in reg['arms']}
  mask=np.isin(d['owner'],bundle['fold']['fit'])&(d['batch']>0)
  for name,model in bundle['models'].items():
   x=d['personal'][mask] if name.endswith('_personal') else d['x'][mask]
   assert model['fit_rows']==mask.sum() and not model['parents']
   assert model['real_people']==len(bundle['fold']['fit'])
   state=model['preprocess'];scaler=state['scaler']
   assert scaler.n_samples_seen_==len(x)
   assert np.allclose(state['medians'],np.median(x,axis=0))
   assert np.allclose(scaler.mean_,x.astype(float).mean(0),atol=1e-9)
   assert np.allclose(scaler.var_,x.astype(float).var(0),atol=1e-9)
   assert x.shape[1]==(128*(s['windows_per_batch']+1) if name.endswith('_personal') else 128)
   assert scaler.n_features_in_==x.shape[1]
   assert model['encoder'] is None
   if name.startswith(('node','tabnet')):
    assert model['epochs']==100 and model['features']==x.shape[1]
   else:assert model['estimator'].n_features_in_==x.shape[1]
   follow=d['batch']>0
   features=d['personal'][follow] if name.endswith('_personal') else d['x'][follow]
   owner=d['owner'][follow]
   scores=predict(model,features)
   with np.load(out/size/'predictions.npz') as saved:
    grouped=np.array([scores[owner==uid].mean() for uid in saved['ids']])
    np.testing.assert_allclose(grouped,saved[name][record['index']-1],rtol=1e-7,atol=1e-8)
  print(size,'fold',record['index'],'all eight checkpoints and predictions verified',flush=True)
 r=results['scenarios'][size]
 assert sha256(out/size/'predictions.npz')==r['predictions_sha256']
 with np.load(out/size/'predictions.npz') as predictions:
  for a in r['aggregates']:
   mask=predictions['split']==a['role'];y=predictions['y'][mask]
   p=predictions[a['family']+'_'+a['arm']][:,mask]
   assert p.shape==(25,a['people'])
   for key,values in [('accuracy',[accuracy_score(y,row>=.5) for row in p]),('auroc',[roc_auc_score(y,row) for row in p])]:
    assert np.isclose(np.mean(values),a[key]['mean']) and np.isclose(np.std(values,ddof=1),a[key]['sd'])
   assert np.isclose(accuracy_score(y,p.mean(0)>=.5),a['ensemble']['accuracy'])
   assert np.isclose(roc_auc_score(y,p.mean(0)),a['ensemble']['auroc'])
write_json(out/'verification.json',dict(passed=True,fits=400,checks=['real event provenance and no reuse within either scenario',
 'baseline precedes follow-up; separate visits for 400 keys','no cross-batch successor timing in baseline',
 'full chronological baseline matrix concatenated exactly; no timing summaries or baseline summary features','participant assignments retained; identical folds across arms',
 '400 preprocessing states fit only their CV training follow-up rows','all checkpoint and encoder hashes unchanged', 'all 400 saved participant predictions reproduced from checkpoints',
 'all accuracy/AUROC/sample SD and ensembles reproduce','prior training and inference functions unchanged'],audit_sha256=sha256(__file__)))
with zipfile.ZipFile(out/'audit_source.zip','x',compression=zipfile.ZIP_DEFLATED) as z:z.write(__file__,'verify.py')
print('Full 300/400 verification passed.',flush=True)
